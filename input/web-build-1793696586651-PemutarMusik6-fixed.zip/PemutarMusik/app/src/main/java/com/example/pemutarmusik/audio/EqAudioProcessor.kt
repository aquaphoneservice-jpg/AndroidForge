package com.example.pemutarmusik.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sin
import kotlin.math.sqrt

/** Semua pengaturan DSP. Objek ini tidak pernah diubah setelah dibuat (aman antar-thread). */
class DspParams(
    val eqEnabled: Boolean = true,
    val gains: FloatArray = FloatArray(EqAudioProcessor.BAND_COUNT),
    val preampDb: Float = 0f,
    val noiseFilter: Boolean = true,
    val bassBoost: Float = 0f,   // 0..1
    val width: Float = 1f,       // 0..2 (1 = normal)
    val ampDb: Float = 3f,       // 0..+12 dB (loudness / power amp)
)

/**
 * Mesin DSP (dihitung 64-bit, dibulatkan ke 16-bit di akhir dengan dither).
 *
 * Urutan sinyal:
 *   PREAMP (+ AUTO HEADROOM) -> NOISE FILTER -> EQUALIZER 10 band -> BASS BOOSTER
 *   -> BASS GUARD otomatis -> STEREO WIDTH -> POWER AMP (gain)
 *   -> LOOK-AHEAD LIMITER (brick-wall, tanpa clipping) -> dither -> keluar
 *
 * Kenapa tidak pecah:
 *  - AUTO HEADROOM: gain total EQ + bass booster dihitung dari kurva responsnya, lalu preamp
 *    otomatis diturunkan sebesar puncak boost itu. Jadi boost EQ tidak membuat sinyal melewati 0 dBFS.
 *  - Limiter look-ahead 5 ms: gain diturunkan HALUS sebelum puncak tiba, dan dilepas pelan (120 ms).
 *    Tidak ada pemotongan gelombang (hard/soft clip), jadi bass tetap bersih.
 *  - Bass Guard otomatis menekan bass yang terlalu besar sebelum masuk limiter.
 * Kenapa tidak kecil: POWER AMP menaikkan level (sampai +12 dB) dan limiter menjaganya tetap aman,
 * sehingga rata-rata volume jauh lebih keras tanpa distorsi.
 */
class EqAudioProcessor : BaseAudioProcessor() {

    companion object {
        const val BAND_COUNT = 10
        val BAND_FREQS = floatArrayOf(31.25f, 62.5f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
        const val MAX_GAIN_DB = 12f
        const val SPECTRUM_SIZE = 2048

        private const val MAX_CHANNELS = 8
        private const val BAND_Q = 1.41
        private const val BASS_SPLIT_HZ = 120.0
        private const val GUARD_THRESHOLD_DB = -6.0
        private const val GUARD_RATIO = 3.0
        private const val GUARD_MAX_REDUCTION_DB = 12.0
        private const val GATE_THRESHOLD_DB = -62.0
        private const val GATE_RATIO = 1.5
        private const val GATE_MAX_REDUCTION_DB = 12.0
        private const val CONTROL_INTERVAL = 32
        private const val CEILING = 0.944          // -0.5 dBFS
        private const val LOOKAHEAD_SEC = 0.005
        private const val LIMITER_RELEASE_SEC = 0.120
    }

    @Volatile private var params = DspParams()
    private var applied: DspParams? = null

    fun setParams(p: DspParams) {
        params = p
    }

    /** Bass guard sedang menekan bass berapa dB (0 = aman). */
    @Volatile
    var guardReductionDb: Float = 0f
        private set

    /** Limiter sedang menurunkan level berapa dB (0 = tidak bekerja). */
    @Volatile
    var limiterReductionDb: Float = 0f
        private set

    /** Penurunan preamp otomatis (dB) agar boost EQ/bass tidak membuat clipping. */
    @Volatile
    var headroomTrimDb: Float = 0f
        private set

    @Volatile
    var sampleRateHz: Int = 44100
        private set

    // ---- Buffer untuk spectrum analyzer ----
    private val ring = FloatArray(SPECTRUM_SIZE)
    private var writePos = 0
    @Volatile private var publishedPos = 0

    fun snapshot(dst: FloatArray) {
        val end = publishedPos
        val mask = SPECTRUM_SIZE - 1
        for (i in 0 until SPECTRUM_SIZE) dst[i] = ring[(end - SPECTRUM_SIZE + i) and mask]
    }

    // ---- State thread audio ----
    private var channels = 0
    private var sr = 44100

    private val eqCoef = DoubleArray(BAND_COUNT * 5)
    private var eqZ = DoubleArray(0)
    private val hpCoef = DoubleArray(5)
    private var hpZ = DoubleArray(0)
    private val shelfCoef = DoubleArray(5)
    private var shelfZ = DoubleArray(0)
    private val lpCoef = DoubleArray(5)
    private var lpZ = DoubleArray(0)

    private val tmp = DoubleArray(MAX_CHANNELS)

    private var preGain = 1.0
    private var ampGain = 1.0
    private var boost = 0.0
    private var boostActive = false
    private var widthF = 1.0
    private var eqOn = true
    private var noiseOn = true

    private var guardEnv = 0.0
    private var guardGain = 1.0
    private var guardTarget = 1.0
    private var guardAttack = 0.0
    private var guardRelease = 0.0
    private var guardEnvAttack = 0.0
    private var guardEnvRelease = 0.0

    private var gateEnv = 0.0
    private var gateGain = 1.0
    private var gateTarget = 1.0
    private var gateAttack = 0.0
    private var gateRelease = 0.0

    private var controlCounter = 0
    private var rng = 0x2545F491

    // ---- Look-ahead limiter ----
    private var lookahead = 1
    private var delayBuf = DoubleArray(0)       // [lookahead][channel]
    private var delayPos = 0
    private var dqIdx = LongArray(0)
    private var dqVal = DoubleArray(0)
    private var dqHead = 0
    private var dqCount = 0
    private var frameCounter = 0L
    private var boxBuf = DoubleArray(0)
    private var boxPos = 0
    private var boxSum = 0.0
    private var limGain = 1.0
    private var limRelease = 0.0

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT ||
            inputAudioFormat.channelCount !in 1..MAX_CHANNELS
        ) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun onFlush() {
        channels = inputAudioFormat.channelCount
        sr = inputAudioFormat.sampleRate
        sampleRateHz = sr
        eqZ = DoubleArray(channels * BAND_COUNT * 2)
        hpZ = DoubleArray(channels * 2)
        shelfZ = DoubleArray(channels * 2)
        lpZ = DoubleArray(channels * 2)

        guardEnv = 0.0; guardGain = 1.0; guardTarget = 1.0
        gateEnv = 0.0; gateGain = 1.0; gateTarget = 1.0
        controlCounter = 0
        guardEnvAttack = 1.0 - exp(-1.0 / (0.004 * sr))
        guardEnvRelease = 1.0 - exp(-1.0 / (0.200 * sr))
        guardAttack = 1.0 - exp(-1.0 / (0.003 * sr))
        guardRelease = 1.0 - exp(-1.0 / (0.150 * sr))
        gateAttack = 1.0 - exp(-1.0 / (0.002 * sr))
        gateRelease = 1.0 - exp(-1.0 / (0.120 * sr))

        lookahead = max(1, (LOOKAHEAD_SEC * sr).toInt())
        delayBuf = DoubleArray(lookahead * channels)
        delayPos = 0
        val cap = lookahead + 3
        dqIdx = LongArray(cap)
        dqVal = DoubleArray(cap)
        dqHead = 0
        dqCount = 0
        frameCounter = 0L
        boxBuf = DoubleArray(lookahead) { 1.0 }
        boxPos = 0
        boxSum = lookahead.toDouble()
        limGain = 1.0
        limRelease = 1.0 - exp(-1.0 / (LIMITER_RELEASE_SEC * sr))

        applied = null
        guardReductionDb = 0f
        limiterReductionDb = 0f
    }

    private fun nextUnit(): Double {
        var x = rng
        x = x xor (x shl 13)
        x = x xor (x ushr 17)
        x = x xor (x shl 5)
        rng = x
        return (x ushr 8) / 16777216.0
    }

    private fun bq(c: DoubleArray, co: Int, z: DoubleArray, zi: Int, x: Double): Double {
        val y = c[co] * x + z[zi]
        z[zi] = c[co + 1] * x - c[co + 3] * y + z[zi + 1]
        z[zi + 1] = c[co + 2] * x - c[co + 4] * y
        return y
    }

    /** Minimum jendela geser (monotonic deque): min dari r[n-lookahead .. n]. */
    private fun slidingMin(r: Double): Double {
        val cap = dqIdx.size
        val n = frameCounter
        // buang dari belakang yang >= r
        while (dqCount > 0) {
            val last = (dqHead + dqCount - 1) % cap
            if (dqVal[last] >= r) dqCount-- else break
        }
        val pos = (dqHead + dqCount) % cap
        dqIdx[pos] = n
        dqVal[pos] = r
        dqCount++
        // buang dari depan yang sudah keluar jendela (ukuran lookahead + 1)
        while (dqCount > 0 && dqIdx[dqHead] <= n - (lookahead + 1)) {
            dqHead = (dqHead + 1) % cap
            dqCount--
        }
        frameCounter = n + 1
        return dqVal[dqHead]
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return

        val out = replaceOutputBuffer(size).order(ByteOrder.LITTLE_ENDIAN)
        val input = inputBuffer.slice().order(ByteOrder.LITTLE_ENDIAN)
        inputBuffer.position(inputBuffer.limit())

        if (channels == 0) {
            out.put(input)
            out.flip()
            return
        }

        val p = params
        if (p !== applied) {
            applied = p
            applyParams(p)
        }

        val ch = channels
        val frames = size / (2 * ch)
        val inv = 1.0 / 32768.0
        val ringMask = SPECTRUM_SIZE - 1
        var minLim = 1.0

        for (f in 0 until frames) {
            // ---- A: preamp (+ auto headroom) + rumble filter ----
            var inPeak = 0.0
            for (c in 0 until ch) {
                var x = input.getShort() * inv * preGain
                if (noiseOn) x = bq(hpCoef, 0, hpZ, c * 2, x)
                tmp[c] = x
                val a = abs(x)
                if (a > inPeak) inPeak = a
            }

            // ---- noise gate halus ----
            if (noiseOn) {
                gateEnv += (if (inPeak > gateEnv) gateAttack else gateRelease) * (inPeak - gateEnv)
                val g = gateGain
                gateGain = g + (gateTarget - g) * (if (gateTarget > g) 0.01 else 0.0015)
            } else {
                gateGain = 1.0
                gateTarget = 1.0
            }

            // ---- B: EQ, bass booster, bass guard ----
            var bassPeak = 0.0
            for (c in 0 until ch) {
                var x = tmp[c] * gateGain

                if (eqOn) {
                    var zi = c * BAND_COUNT * 2
                    var ci = 0
                    for (b in 0 until BAND_COUNT) {
                        x = bq(eqCoef, ci, eqZ, zi, x)
                        zi += 2
                        ci += 5
                    }
                }
                if (boostActive) x = bq(shelfCoef, 0, shelfZ, c * 2, x)

                val l = bq(lpCoef, 0, lpZ, c * 2, x)      // komponen bass
                x -= (1.0 - guardGain) * l                 // bass guard (otomatis)

                val ab = abs(l) * ampGain
                if (ab > bassPeak) bassPeak = ab
                tmp[c] = x
            }

            guardEnv += (if (bassPeak > guardEnv) guardEnvAttack else guardEnvRelease) * (bassPeak - guardEnv)
            if (++controlCounter >= CONTROL_INTERVAL) {
                controlCounter = 0
                val over = 20.0 * log10(max(guardEnv, 1e-6)) - GUARD_THRESHOLD_DB
                guardTarget = if (over > 0.0) {
                    10.0.pow(-min(over * (1.0 - 1.0 / GUARD_RATIO), GUARD_MAX_REDUCTION_DB) / 20.0)
                } else 1.0

                val gdb = 20.0 * log10(max(gateEnv, 1e-6))
                gateTarget = if (noiseOn && gdb < GATE_THRESHOLD_DB) {
                    10.0.pow(-min((GATE_THRESHOLD_DB - gdb) * (1.0 - 1.0 / GATE_RATIO), GATE_MAX_REDUCTION_DB) / 20.0)
                } else 1.0
            }
            guardGain += (guardTarget - guardGain) * (if (guardTarget < guardGain) guardAttack else guardRelease)

            // ---- stereo width ----
            if (ch == 2 && abs(widthF - 1.0) > 0.01) {
                val m = (tmp[0] + tmp[1]) * 0.5
                val s = (tmp[0] - tmp[1]) * 0.5 * widthF
                tmp[0] = m + s
                tmp[1] = m - s
            }

            // ---- C: power amp gain + look-ahead limiter ----
            var peak = 0.0
            for (c in 0 until ch) {
                val v = tmp[c] * ampGain
                tmp[c] = v
                val a = abs(v)
                if (a > peak) peak = a
            }
            val r = if (peak > CEILING) CEILING / peak else 1.0
            val m = slidingMin(r)
            boxSum += m - boxBuf[boxPos]
            boxBuf[boxPos] = m
            boxPos = (boxPos + 1) % lookahead
            val gs = boxSum / lookahead
            limGain = if (gs < limGain) gs else min(gs, limGain + (gs - limGain) * limRelease)
            if (limGain < minLim) minLim = limGain

            var mono = 0.0
            val base = delayPos * ch
            for (c in 0 until ch) {
                val delayed = delayBuf[base + c]
                delayBuf[base + c] = tmp[c]
                val x = delayed * limGain
                mono += x
                val dither = nextUnit() - nextUnit()   // TPDF +-1 LSB
                val v = (x * 32767.0 + dither).roundToInt().coerceIn(-32768, 32767)
                out.putShort(v.toShort())
            }
            delayPos = (delayPos + 1) % lookahead

            ring[writePos and ringMask] = (mono / ch).toFloat()
            writePos++
        }

        while (input.hasRemaining()) out.put(input.get())
        out.flip()

        publishedPos = writePos
        guardReductionDb = (-20.0 * log10(max(guardGain, 1e-6))).toFloat()
        limiterReductionDb = (-20.0 * log10(max(minLim, 1e-6))).toFloat()
    }

    // ------------------------------------------------------------------ koefisien

    private fun applyParams(p: DspParams) {
        eqOn = p.eqEnabled
        noiseOn = p.noiseFilter
        ampGain = 10.0.pow(p.ampDb.coerceIn(0f, 12f) / 20.0)
        boost = p.bassBoost.toDouble().coerceIn(0.0, 1.0)
        boostActive = boost > 0.01
        widthF = p.width.toDouble().coerceIn(0.0, 2.0)

        for (b in 0 until BAND_COUNT) {
            val f = BAND_FREQS[b].toDouble()
            val db = p.gains.getOrElse(b) { 0f }.toDouble()
            if (abs(db) < 0.01 || f >= sr * 0.45) identity(eqCoef, b * 5) else peaking(f, db, BAND_Q, eqCoef, b * 5)
        }
        if (boostActive) lowShelf(90.0, boost * 9.0, shelfCoef) else identity(shelfCoef, 0)
        highPass(30.0, hpCoef)
        lowPass(BASS_SPLIT_HZ, lpCoef)

        // AUTO HEADROOM: cari puncak respons total EQ + bass booster, turunkan preamp sebesar itu
        var peakDb = 0.0
        for (i in 0 until 96) {
            val f = 20.0 * 1000.0.pow(i / 95.0)
            if (f >= sr * 0.48) break
            val w = 2.0 * PI * f / sr
            var db = 0.0
            if (eqOn) for (b in 0 until BAND_COUNT) db += magDb(eqCoef, b * 5, w)
            if (boostActive) db += magDb(shelfCoef, 0, w)
            if (db > peakDb) peakDb = db
        }
        val trim = max(0.0, peakDb - 1.5)   // sisakan 1,5 dB: musik jarang penuh di semua frekuensi
        headroomTrimDb = trim.toFloat()
        preGain = 10.0.pow((p.preampDb - trim) / 20.0)
    }

    private fun magDb(c: DoubleArray, o: Int, w: Double): Double {
        val c1 = cos(w); val s1 = sin(w); val c2 = cos(2 * w); val s2 = sin(2 * w)
        val nr = c[o] + c[o + 1] * c1 + c[o + 2] * c2
        val ni = c[o + 1] * s1 + c[o + 2] * s2
        val dr = 1.0 + c[o + 3] * c1 + c[o + 4] * c2
        val di = c[o + 3] * s1 + c[o + 4] * s2
        val num = nr * nr + ni * ni
        val den = dr * dr + di * di
        return 10.0 * log10(max(num, 1e-12) / max(den, 1e-12))
    }

    private fun identity(c: DoubleArray, o: Int) {
        c[o] = 1.0; c[o + 1] = 0.0; c[o + 2] = 0.0; c[o + 3] = 0.0; c[o + 4] = 0.0
    }

    // Rumus dari RBJ "Audio EQ Cookbook". Hasil: [b0 b1 b2 a1 a2] sudah dinormalisasi.
    private fun peaking(f: Double, db: Double, q: Double, c: DoubleArray, o: Int) {
        val a = 10.0.pow(db / 40.0)
        val w0 = 2.0 * PI * f / sr
        val cw = cos(w0)
        val alpha = sin(w0) / (2.0 * q)
        val a0 = 1.0 + alpha / a
        c[o] = (1.0 + alpha * a) / a0
        c[o + 1] = (-2.0 * cw) / a0
        c[o + 2] = (1.0 - alpha * a) / a0
        c[o + 3] = (-2.0 * cw) / a0
        c[o + 4] = (1.0 - alpha / a) / a0
    }

    private fun lowShelf(f: Double, db: Double, c: DoubleArray) {
        val a = 10.0.pow(db / 40.0)
        val w0 = 2.0 * PI * f / sr
        val cw = cos(w0)
        val alpha = sin(w0) / 2.0 * sqrt(2.0)
        val t = 2.0 * sqrt(a) * alpha
        val a0 = (a + 1) + (a - 1) * cw + t
        c[0] = a * ((a + 1) - (a - 1) * cw + t) / a0
        c[1] = 2 * a * ((a - 1) - (a + 1) * cw) / a0
        c[2] = a * ((a + 1) - (a - 1) * cw - t) / a0
        c[3] = -2 * ((a - 1) + (a + 1) * cw) / a0
        c[4] = ((a + 1) + (a - 1) * cw - t) / a0
    }

    private fun highPass(f: Double, c: DoubleArray) {
        val w0 = 2.0 * PI * f / sr
        val cw = cos(w0)
        val alpha = sin(w0) / (2.0 * 0.70710678)
        val a0 = 1.0 + alpha
        c[0] = (1.0 + cw) / 2.0 / a0
        c[1] = -(1.0 + cw) / a0
        c[2] = (1.0 + cw) / 2.0 / a0
        c[3] = (-2.0 * cw) / a0
        c[4] = (1.0 - alpha) / a0
    }

    private fun lowPass(f: Double, c: DoubleArray) {
        val w0 = 2.0 * PI * f / sr
        val cw = cos(w0)
        val alpha = sin(w0) / (2.0 * 0.70710678)
        val a0 = 1.0 + alpha
        c[0] = (1.0 - cw) / 2.0 / a0
        c[1] = (1.0 - cw) / a0
        c[2] = (1.0 - cw) / 2.0 / a0
        c[3] = (-2.0 * cw) / a0
        c[4] = (1.0 - alpha) / a0
    }
}
