package com.example.pemutarmusik

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.IntentSenderRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.ime
import androidx.compose.foundation.layout.imePadding
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pemutarmusik.audio.AudioEngine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(applicationContext)
        Skin.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { PlayerApp() }
        }
    }

    override fun onResume() {
        super.onResume()
        // Kembali ke aplikasi = mini player melayang ditutup (seperti restore di Winamp)
        stopService(Intent(this, FloatingPlayerService::class.java))
    }
}

/** Minimize ala Winamp: app turun ke belakang, mini player melayang tampil di depan. */
private fun minimizeToFloating(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "Aktifkan \"Tampil di atas aplikasi lain\" untuk MP3, lalu tekan minimize lagi.",
            Toast.LENGTH_LONG,
        ).show()
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        )
        return
    }
    context.startService(Intent(context, FloatingPlayerService::class.java))
    (context as? Activity)?.moveTaskToBack(true)
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

private fun requestedPermissions(): Array<String> = when {
    Build.VERSION.SDK_INT >= 33 -> arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
    // Android 9 ke bawah: butuh izin tulis untuk menghapus file lagu
    Build.VERSION.SDK_INT <= 28 -> arrayOf(audioPermission(), Manifest.permission.WRITE_EXTERNAL_STORAGE)
    else -> arrayOf(audioPermission())
}

@Composable
fun PlayerApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(context)
    }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(requestedPermissions())
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs()
    }

    val deleteLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartIntentSenderForResult()) { res ->
        vm.onDeleteResult(res.resultCode == Activity.RESULT_OK)
    }
    val onDeleteSong: (Song) -> Unit = { song ->
        when (val outcome = vm.requestDelete(song)) {
            is DeleteOutcome.NeedsUser -> deleteLauncher.launch(IntentSenderRequest.Builder(outcome.sender).build())
            DeleteOutcome.Done -> Toast.makeText(context, "Lagu dihapus", Toast.LENGTH_SHORT).show()
            DeleteOutcome.Failed -> Toast.makeText(context, "Gagal menghapus lagu", Toast.LENGTH_SHORT).show()
        }
    }

    var showEq by rememberSaveable { mutableStateOf(true) }
    var showDsp by rememberSaveable { mutableStateOf(false) }
    var showPl by rememberSaveable { mutableStateOf(true) }

    Column(
        Modifier
            .fillMaxSize()
            .background(WA_DESK)
            .statusBarsPadding()
            .navigationBarsPadding()
            .imePadding()
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        MainWindow(
            vm = vm,
            showEq = showEq,
            showDsp = showDsp,
            showPl = showPl,
            onToggleEq = { showEq = !showEq },
            onToggleDsp = { showDsp = !showDsp },
            onTogglePl = { showPl = !showPl },
            onMinimize = { minimizeToFloating(context) },
        )
        // saat mengetik di kolom cari, EQ/DSP disembunyikan sementara supaya playlist terlihat
        val typing = WindowInsets.ime.getBottom(LocalDensity.current) > 0
        if (showEq && !typing) EqWindow()
        if (showDsp && !typing) DspWindow()
        if (showPl) {
            PlaylistWindow(
                vm = vm,
                granted = granted,
                onRequestPermission = { launcher.launch(requestedPermissions()) },
                onDeleteSong = onDeleteSong,
                modifier = Modifier.weight(1f),
            )
        }
    }
}
