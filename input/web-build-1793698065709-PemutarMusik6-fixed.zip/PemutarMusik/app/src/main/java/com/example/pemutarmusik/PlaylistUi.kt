package com.example.pemutarmusik

import android.os.Build
import android.text.format.Formatter
import android.widget.Toast
import androidx.compose.foundation.ExperimentalFoundationApi
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material3.Icon
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private const val ALL = -1L

/** Data untuk dialog "buat album baru". */
private class NewAlbum(val songIds: List<Long>, val removeFromAlbum: Long?, val removeSongId: Long?)

// ================================================================== DIALOG DASAR

@Composable
private fun WaAlert(
    title: String,
    onDismiss: () -> Unit,
    confirmText: String? = null,
    onConfirm: () -> Unit = {},
    content: @Composable ColumnScope.() -> Unit,
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = Color(0xFF1B2F66),
        titleContentColor = Color.White,
        textContentColor = WA_GREEN,
        title = { Text(title, fontFamily = MONO, fontSize = 14.sp, fontWeight = FontWeight.Bold) },
        text = { Column(content = content) },
        confirmButton = {
            if (confirmText != null) {
                TextButton(onClick = onConfirm) {
                    Text(confirmText, color = Skin.p.c1, fontFamily = MONO, fontWeight = FontWeight.Bold)
                }
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text(if (confirmText != null) "BATAL" else "TUTUP", color = WA_GREEN_DIM, fontFamily = MONO, fontWeight = FontWeight.Bold)
            }
        },
    )
}

@Composable
private fun NameDialog(title: String, initial: String, confirm: String, onConfirm: (String) -> Unit, onDismiss: () -> Unit) {
    var text by remember { mutableStateOf(initial) }
    WaAlert(title, onDismiss, confirm, onConfirm = { if (text.isNotBlank()) onConfirm(text) }) {
        OutlinedTextField(
            value = text,
            onValueChange = { text = it.take(30) },
            singleLine = true,
            label = { Text("Nama album") },
            textStyle = TextStyle(color = Color.White, fontFamily = MONO, fontSize = 14.sp),
        )
    }
}

@Composable
private fun DetailRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 2.dp)) {
        Text(label, color = WA_GREEN_DIM, fontSize = 11.sp, fontFamily = MONO, modifier = Modifier.width(84.dp))
        Text(value, color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, modifier = Modifier.weight(1f))
    }
}

@Composable
private fun DetailsDialog(song: Song, onDismiss: () -> Unit) {
    val context = LocalContext.current
    val kbps = if (song.durationMs > 0) (song.sizeBytes * 8 / song.durationMs).toInt() else 0
    val date = if (song.dateAddedSec > 0) {
        SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault()).format(Date(song.dateAddedSec * 1000))
    } else "-"
    WaAlert("Rincian", onDismiss) {
        DetailRow("Judul", song.title)
        DetailRow("Artis", song.artist)
        DetailRow("Album", song.album)
        DetailRow("Durasi", formatTime(song.durationMs))
        DetailRow("Ukuran", Formatter.formatShortFileSize(context, song.sizeBytes))
        DetailRow("Bitrate", if (kbps > 0) "~$kbps kbps" else "-")
        DetailRow("File", song.fileName)
        DetailRow("Lokasi", song.path.ifBlank { "-" })
        DetailRow("Ditambah", date)
    }
}

// ================================================================== JENDELA PLAYLIST

@OptIn(ExperimentalFoundationApi::class)
@Composable
fun PlaylistWindow(
    vm: PlayerViewModel,
    granted: Boolean,
    onRequestPermission: () -> Unit,
    onDeleteSong: (Song) -> Unit,
    modifier: Modifier = Modifier,
) {
    val context = LocalContext.current
    val songs by vm.songs.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val albums by vm.albums.collectAsState()
    val ui by vm.ui.collectAsState()

    var selected by rememberSaveable { mutableStateOf(ALL) }
    val current = albums.firstOrNull { it.id == selected }          // null = tampilkan semua lagu
    val byId = remember(songs) { songs.associateBy { it.id } }
    val list = if (current == null) songs else current.songIds.mapNotNull { byId[it] }

    var query by rememberSaveable { mutableStateOf("") }
    val q = query.trim()
    val shown = if (q.isEmpty()) list else list.filter {
        it.title.contains(q, ignoreCase = true) || it.artist.contains(q, ignoreCase = true) ||
            it.album.contains(q, ignoreCase = true)
    }

    var details by remember { mutableStateOf<Song?>(null) }
    var moveSong by remember { mutableStateOf<Song?>(null) }
    var deleteConfirm by remember { mutableStateOf<Song?>(null) }
    var newAlbum by remember { mutableStateOf<NewAlbum?>(null) }
    var renameAlbum by remember { mutableStateOf<Album?>(null) }
    var addDialog by remember { mutableStateOf(false) }
    var albumMenu by remember { mutableStateOf<Long?>(null) }

    fun toast(msg: String) = Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()

    WaWindow("PLAYLIST", modifier, fill = true) {
        // ---- baris album: SEMUA | album... | + ----
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()),
            horizontalArrangement = Arrangement.spacedBy(4.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            WaButton("SEMUA", { selected = ALL }, active = current == null)
            albums.forEach { a ->
                Box {
                    WaButton(
                        a.name,
                        { selected = a.id },
                        active = current?.id == a.id,
                        onLongClick = { albumMenu = a.id },
                    )
                    DropdownMenu(
                        expanded = albumMenu == a.id,
                        onDismissRequest = { albumMenu = null },
                        containerColor = Color(0xFFD5DBE8),
                    ) {
                        MenuItem("Ganti nama") { albumMenu = null; renameAlbum = a }
                        MenuItem("Hapus album") {
                            albumMenu = null
                            vm.deleteAlbum(a.id)
                            if (selected == a.id) selected = ALL
                            toast("Album dihapus")
                        }
                    }
                }
            }
            WaButton("+", { newAlbum = NewAlbum(emptyList(), null, null) })
        }
        Spacer(Modifier.height(4.dp))

        // ---- daftar lagu ----
        Box(Modifier.weight(1f).fillMaxWidth().bevel(false, WA_LCD)) {
            when {
                !granted -> Column(
                    Modifier.fillMaxSize().padding(12.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp, Alignment.CenterVertically),
                    horizontalAlignment = Alignment.CenterHorizontally,
                ) {
                    Text("Butuh izin membaca file musik (MP3).", color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center)
                    WaButton("IZINKAN AKSES MUSIK", onRequestPermission)
                    Text(
                        "Kalau dialog tidak muncul: Pengaturan > Aplikasi > MP3 > Izin.",
                        color = WA_GREEN_DIM, fontSize = 9.sp, fontFamily = MONO, textAlign = TextAlign.Center,
                    )
                }
                current == null && loaded && songs.isEmpty() -> Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text("Tidak ada file MP3 di penyimpanan.", color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center)
                }
                current != null && list.isEmpty() -> Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text(
                        "Album masih kosong.\nTekan TAMBAH di bawah, atau tekan lama lagu di SEMUA lalu pilih \"Pindah ke album\".",
                        color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center,
                    )
                }
                q.isNotEmpty() && shown.isEmpty() -> Box(Modifier.fillMaxSize().padding(12.dp), contentAlignment = Alignment.Center) {
                    Text("Tidak ada lagu yang cocok dengan \"$q\".", color = WA_GREEN, fontSize = 11.sp, fontFamily = MONO, textAlign = TextAlign.Center)
                }
                else -> {
                    val listState = rememberLazyListState()
                    LaunchedEffect(ui.mediaId, shown.size) {
                        val idx = shown.indexOfFirst { it.id.toString() == ui.mediaId }
                        if (idx >= 0) listState.animateScrollToItem(idx)
                    }
                    LazyColumn(Modifier.fillMaxSize(), state = listState) {
                        itemsIndexed(shown, key = { _, song -> song.id }) { index, song ->
                            var menu by remember { mutableStateOf(false) }
                            val isCurrent = song.id.toString() == ui.mediaId
                            Box {
                                Row(
                                    Modifier
                                        .fillMaxWidth()
                                        .background(if (isCurrent) WA_SEL else Color.Transparent)
                                        .combinedClickable(
                                            onClick = { vm.playList(shown, song) },
                                            onLongClick = { menu = true },
                                        )
                                        .padding(horizontal = 4.dp, vertical = 3.dp),
                                ) {
                                    Text(
                                        "${index + 1}. ${song.artist} - ${song.title}",
                                        color = if (isCurrent) Color.White else WA_GREEN,
                                        fontSize = 11.sp,
                                        fontFamily = MONO,
                                        maxLines = 1,
                                        overflow = TextOverflow.Ellipsis,
                                        modifier = Modifier.weight(1f),
                                    )
                                    Spacer(Modifier.width(6.dp))
                                    Text(
                                        formatTime(song.durationMs),
                                        color = if (isCurrent) Color.White else WA_GREEN,
                                        fontSize = 11.sp,
                                        fontFamily = MONO,
                                    )
                                }
                                DropdownMenu(
                                    expanded = menu,
                                    onDismissRequest = { menu = false },
                                    containerColor = Color(0xFFD5DBE8),
                                ) {
                                    MenuItem("Pindah ke album") { menu = false; moveSong = song }
                                    if (current != null && q.isEmpty()) {
                                        MenuItem("Naikkan urutan", enabled = index > 0) {
                                            menu = false
                                            vm.moveInAlbum(current.id, song.id, -1)
                                        }
                                        MenuItem("Turunkan urutan", enabled = index < shown.lastIndex) {
                                            menu = false
                                            vm.moveInAlbum(current.id, song.id, +1)
                                        }
                                        MenuItem("Keluarkan dari album") {
                                            menu = false
                                            vm.removeFromAlbum(current.id, song.id)
                                        }
                                    }
                                    MenuItem("Hapus lagu") {
                                        menu = false
                                        // Android 11+: sistem sudah menampilkan konfirmasinya sendiri
                                        if (Build.VERSION.SDK_INT >= 30) onDeleteSong(song) else deleteConfirm = song
                                    }
                                    MenuItem("Rincian") { menu = false; details = song }
                                }
                            }
                        }
                    }
                }
            }
        }

        // ---- footer ----
        Spacer(Modifier.height(4.dp))
        Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            Text(
                "${shown.size} LAGU" + (current?.let { " - ${it.name}" } ?: ""),
                color = WA_INK, fontSize = 9.sp, fontFamily = MONO, maxLines = 1, overflow = TextOverflow.Ellipsis,
                modifier = Modifier.weight(1f),
            )
            if (granted && current != null) WaButton("TAMBAH", { addDialog = true })
            if (granted) WaButton("REFRESH", vm::loadSongs)
        }
        // ---- kolom cari lagu ----
        Spacer(Modifier.height(4.dp))
        SearchField(query, { query = it }, Modifier.fillMaxWidth())
    }

    // ================= dialog =================

    details?.let { song -> DetailsDialog(song) { details = null } }

    deleteConfirm?.let { song ->
        WaAlert("Hapus lagu?", { deleteConfirm = null }, "HAPUS", onConfirm = {
            deleteConfirm = null
            onDeleteSong(song)
        }) {
            Text(song.title, color = Color.White, fontFamily = MONO, fontSize = 13.sp)
            Spacer(Modifier.height(6.dp))
            Text("File akan dihapus permanen dari HP dan tidak bisa dikembalikan.", fontFamily = MONO, fontSize = 11.sp)
        }
    }

    moveSong?.let { song ->
        WaAlert("Pindah ke album", { moveSong = null }) {
            Text(song.title, color = Color.White, fontFamily = MONO, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Spacer(Modifier.height(8.dp))
            albums.forEach { a ->
                Text(
                    "▸ ${a.name}",
                    color = WA_GREEN, fontFamily = MONO, fontSize = 13.sp,
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            moveSong = null
                            if (a.id != current?.id) {
                                vm.addToAlbum(a.id, listOf(song.id))
                                // di dalam album = benar-benar dipindah (dikeluarkan dari album asal)
                                current?.let { vm.removeFromAlbum(it.id, song.id) }
                                toast("Dipindah ke ${a.name}")
                            }
                        }
                        .padding(vertical = 8.dp),
                )
            }
            Text(
                "+ Album baru...",
                color = Skin.p.c1, fontFamily = MONO, fontSize = 13.sp, fontWeight = FontWeight.Bold,
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable {
                        moveSong = null
                        newAlbum = NewAlbum(listOf(song.id), current?.id, song.id)
                    }
                    .padding(vertical = 8.dp),
            )
        }
    }

    newAlbum?.let { na ->
        NameDialog("Album baru", "", "BUAT", onConfirm = { name ->
            newAlbum = null
            val id = vm.createAlbum(name, na.songIds)
            if (na.removeFromAlbum != null && na.removeSongId != null) vm.removeFromAlbum(na.removeFromAlbum, na.removeSongId)
            selected = id
            toast("Album \"$name\" dibuat")
        }, onDismiss = { newAlbum = null })
    }

    renameAlbum?.let { a ->
        NameDialog("Ganti nama album", a.name, "SIMPAN", onConfirm = { name ->
            renameAlbum = null
            vm.renameAlbum(a.id, name)
        }, onDismiss = { renameAlbum = null })
    }

    if (addDialog && current != null) {
        AddSongsDialog(
            albumName = current.name,
            candidates = songs.filter { it.id !in current.songIds },
            onConfirm = { ids ->
                addDialog = false
                vm.addToAlbum(current.id, ids)
            },
            onDismiss = { addDialog = false },
        )
    }
}

/** Kolom cari di bagian bawah playlist: filter judul / artis / album saat mengetik. */
@Composable
private fun SearchField(query: String, onChange: (String) -> Unit, modifier: Modifier = Modifier) {
    Row(
        modifier.height(28.dp).bevel(false, WA_LCD, 14.dp).padding(horizontal = 9.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Icon(AppIcons.Search, contentDescription = "Cari", tint = Skin.p.c1, modifier = Modifier.size(16.dp))
        Spacer(Modifier.width(6.dp))
        Box(Modifier.weight(1f), contentAlignment = Alignment.CenterStart) {
            if (query.isEmpty()) {
                Text("Cari lagu, artis, album...", color = WA_GREEN_DIM, fontSize = 11.sp, fontFamily = MONO, maxLines = 1)
            }
            BasicTextField(
                value = query,
                onValueChange = onChange,
                singleLine = true,
                textStyle = TextStyle(color = Color.White, fontFamily = MONO, fontSize = 12.sp),
                cursorBrush = SolidColor(Skin.p.c1),
                modifier = Modifier.fillMaxWidth(),
            )
        }
        if (query.isNotEmpty()) {
            Icon(
                AppIcons.Close,
                contentDescription = "Hapus pencarian",
                tint = WA_GREEN,
                modifier = Modifier.size(18.dp).clickable { onChange("") },
            )
        }
    }
}

@Composable
private fun MenuItem(text: String, enabled: Boolean = true, onClick: () -> Unit) {
    DropdownMenuItem(
        text = { Text(text, color = if (enabled) WA_INK else WA_LAMP_OFF, fontFamily = MONO, fontSize = 13.sp) },
        onClick = onClick,
        enabled = enabled,
    )
}

/** Pilih beberapa lagu; urutan ketukan = urutan lagu di album (ditandai nomor 1, 2, 3, ...). */
@Composable
private fun AddSongsDialog(
    albumName: String,
    candidates: List<Song>,
    onConfirm: (List<Long>) -> Unit,
    onDismiss: () -> Unit,
) {
    var chosen by remember { mutableStateOf(listOf<Long>()) }
    WaAlert("Tambah ke $albumName", onDismiss, "TAMBAH (${chosen.size})", onConfirm = { onConfirm(chosen) }) {
        Text("Ketuk lagu sesuai urutan yang kamu mau.", fontFamily = MONO, fontSize = 10.sp)
        Spacer(Modifier.height(6.dp))
        if (candidates.isEmpty()) {
            Text("Semua lagu sudah ada di album ini.", fontFamily = MONO, fontSize = 12.sp)
        }
        LazyColumn(Modifier.height(300.dp)) {
            items(candidates, key = { it.id }) { s ->
                val pos = chosen.indexOf(s.id)
                Row(
                    Modifier
                        .fillMaxWidth()
                        .clickable { chosen = if (pos >= 0) chosen - s.id else chosen + s.id }
                        .padding(vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Box(
                        Modifier
                            .size(24.dp)
                            .background(if (pos >= 0) Skin.p.c3 else Color.Transparent, CircleShape)
                            .border(1.5.dp, if (pos >= 0) Skin.p.c3 else WA_GREEN_DIM, CircleShape),
                        contentAlignment = Alignment.Center,
                    ) {
                        if (pos >= 0) Text("${pos + 1}", color = Color.White, fontFamily = MONO, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                    Spacer(Modifier.width(8.dp))
                    Column(Modifier.weight(1f)) {
                        Text(s.title, color = Color.White, fontFamily = MONO, fontSize = 12.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                        Text(s.artist, color = WA_GREEN_DIM, fontFamily = MONO, fontSize = 10.sp, maxLines = 1, overflow = TextOverflow.Ellipsis)
                    }
                }
            }
        }
    }
}
