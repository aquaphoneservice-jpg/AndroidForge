Kasir Ponsel v4.0 - proyek Android (WebView)
Upload ZIP ini ke AndroidForge (Android APK, variant: auto atau debug).
Aplikasi ada di app/src/main/assets/index.html

Baru di v4.0 - Stok produk:
- Tab "Stok": daftar produk, stok, harga beli/jual, nilai stok, filter menipis/habis, kartu stok.
- Catat Pemasukan (Aksesoris / Jasa Service): pilih produk -> stok berkurang, jumlah & modal terisi otomatis.
- Catat Pengeluaran (Belanja Aksesoris): pilih produk -> stok bertambah, harga beli produk bisa ikut diperbarui.
- Edit / hapus transaksi otomatis mengoreksi stok (stok dihitung dari transaksi).
- Pengaturan: centang "Hubungkan ke stok produk" pada jenis mana pun.
- Laporan: Produk terlaris + Stok menipis. Backup CSV kini ikut menyimpan produk & stok.
