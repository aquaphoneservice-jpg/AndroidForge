package com.example.pemutarmusik

import android.app.Service
import android.content.ComponentName
import android.content.Intent
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.media3.common.C
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken

/**
 * Mini player melayang (mode "shade" ala Winamp): tampil di atas semua aplikasi,
 * bisa digeser, berisi judul berjalan, waktu, prev/play/next, kembalikan (buka app) dan tutup.
 * Butuh izin "Tampil di atas aplikasi lain".
 */
class FloatingPlayerService : Service() {

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var titleView: TextView
    private lateinit var timeView: TextView
    private lateinit var playBtn: ImageButton

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildView()
        connectController()
        handler.post(ticker)
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun buildView() {
        val panel = 0xFF1A4F7A.toInt()
        val hi = 0xFF6FC3F0.toInt()
        val lcd = 0xFF020E1A.toInt()
        val aqua = 0xFF4DF0FF.toInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(4f), dp(4f), dp(4f), dp(4f))
            background = GradientDrawable().apply {
                setColor(panel)
                setStroke(dp(2f), hi)
            }
        }

        // layar LCD kecil: judul berjalan + waktu (area ini juga untuk menggeser)
        val lcdBox = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5f), dp(2f), dp(5f), dp(2f))
            background = GradientDrawable().apply { setColor(lcd); setStroke(dp(1f), 0xFF05192B.toInt()) }
        }
        titleView = TextView(this).apply {
            setTextColor(aqua)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 11f)
            typeface = Typeface.MONOSPACE
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isSelected = true
            text = "PEMUTAR MUSIK"
        }
        timeView = TextView(this).apply {
            setTextColor(aqua)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 15f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            text = "00:00"
        }
        lcdBox.addView(titleView, LinearLayout.LayoutParams(dp(130f), LinearLayout.LayoutParams.WRAP_CONTENT))
        lcdBox.addView(timeView)
        box.addView(lcdBox)

        fun imgBtn(res: Int, desc: String, onClick: () -> Unit) = ImageButton(this).apply {
            setImageResource(res)
            setColorFilter(0xFFD6F1FF.toInt())
            contentDescription = desc
            background = GradientDrawable().apply { setColor(panel); setStroke(dp(1f), hi) }
            setOnClickListener { onClick() }
        }
        fun txtBtn(label: String, desc: String, onClick: () -> Unit) = TextView(this).apply {
            text = label
            contentDescription = desc
            gravity = Gravity.CENTER
            setTextColor(0xFFD6F1FF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 13f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            background = GradientDrawable().apply { setColor(panel); setStroke(dp(1f), hi) }
            setOnClickListener { onClick() }
        }

        val size = dp(34f)
        fun lp() = LinearLayout.LayoutParams(size, size).apply { leftMargin = dp(3f) }

        box.addView(imgBtn(android.R.drawable.ic_media_previous, "Sebelumnya") { controller?.seekToPrevious() }, lp())
        playBtn = imgBtn(android.R.drawable.ic_media_play, "Putar/Jeda") {
            controller?.let { if (it.isPlaying) it.pause() else it.play() }
        }
        box.addView(playBtn, lp())
        box.addView(imgBtn(android.R.drawable.ic_media_next, "Berikutnya") { controller?.seekToNextMediaItem() }, lp())
        box.addView(txtBtn("□", "Buka aplikasi") { restoreApp() }, lp())
        box.addView(txtBtn("X", "Tutup") { stopSelf() }, lp())

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.START
            x = dp(8f)
            y = dp(120f)
        }

        // geser dengan menyentuh layar LCD
        var startX = 0
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        lcdBox.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startX = params.x; startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    params.x = startX + (e.rawX - touchX).toInt()
                    params.y = startY + (e.rawY - touchY).toInt()
                    root?.let { wm.updateViewLayout(it, params) }
                    true
                }
                else -> false
            }
        }

        root = box
        wm.addView(box, params)
    }

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = refresh()
                })
                refresh()
            } catch (e: Exception) {
                // abaikan: mini player tetap tampil tapi tombol tidak aktif
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun refresh() {
        val c = controller ?: return
        val md = c.currentMediaItem?.mediaMetadata
        val title = md?.title?.toString()
        if (title != null) {
            titleView.text = "${md?.artist ?: ""} - $title    "
        }
        val pos = c.currentPosition.coerceAtLeast(0L) / 1000
        timeView.text = "%02d:%02d".format(pos / 60, pos % 60)
        playBtn.setImageResource(
            if (c.isPlaying) android.R.drawable.ic_media_pause else android.R.drawable.ic_media_play
        )
    }

    private fun restoreApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        startActivity(intent)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        controller?.release()
        controller = null
        super.onDestroy()
    }
}
