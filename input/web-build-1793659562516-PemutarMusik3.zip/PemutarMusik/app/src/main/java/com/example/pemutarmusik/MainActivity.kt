package com.example.pemutarmusik

import android.Manifest
import android.app.Activity
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.example.pemutarmusik.audio.AudioEngine

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        AudioEngine.init(applicationContext)
        enableEdgeToEdge(
            statusBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
            navigationBarStyle = SystemBarStyle.dark(android.graphics.Color.TRANSPARENT),
        )
        setContent {
            MaterialTheme(colorScheme = darkColorScheme()) { PlayerApp() }
        }
    }

    override fun onResume() {
        super.onResume()
        // Kembali ke aplikasi = mini player melayang ditutup (seperti restore di Winamp)
        stopService(Intent(this, FloatingPlayerService::class.java))
    }
}

/** Minimize ala Winamp: app turun ke belakang, mini player melayang tampil di depan. */
private fun minimizeToFloating(context: Context) {
    if (!Settings.canDrawOverlays(context)) {
        Toast.makeText(
            context,
            "Aktifkan \"Tampil di atas aplikasi lain\" untuk Pemutar Musik, lalu tekan minimize lagi.",
            Toast.LENGTH_LONG,
        ).show()
        context.startActivity(
            Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${context.packageName}"))
        )
        return
    }
    context.startService(Intent(context, FloatingPlayerService::class.java))
    (context as? Activity)?.moveTaskToBack(true)
}

private fun audioPermission(): String =
    if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO
    else Manifest.permission.READ_EXTERNAL_STORAGE

private fun hasAudioPermission(context: Context): Boolean =
    ContextCompat.checkSelfPermission(context, audioPermission()) == PackageManager.PERMISSION_GRANTED

private fun requestedPermissions(): Array<String> =
    if (Build.VERSION.SDK_INT >= 33) arrayOf(audioPermission(), Manifest.permission.POST_NOTIFICATIONS)
    else arrayOf(audioPermission())

@Composable
fun PlayerApp(vm: PlayerViewModel = viewModel()) {
    val context = LocalContext.current
    var granted by remember { mutableStateOf(hasAudioPermission(context)) }
    val launcher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        granted = hasAudioPermission(context)
    }

    LaunchedEffect(Unit) {
        if (!granted) launcher.launch(requestedPermissions())
    }
    LaunchedEffect(granted) {
        if (granted) vm.loadSongs()
    }

    val songs by vm.songs.collectAsState()
    val loaded by vm.loaded.collectAsState()
    val ui by vm.ui.collectAsState()

    var showEq by rememberSaveable { mutableStateOf(true) }
    var showDsp by rememberSaveable { mutableStateOf(false) }
    var showPl by rememberSaveable { mutableStateOf(true) }
    var eqMin by rememberSaveable { mutableStateOf(false) }
    var dspMin by rememberSaveable { mutableStateOf(false) }
    var plMin by rememberSaveable { mutableStateOf(false) }

    Column(
        Modifier
            .fillMaxSize()
            .background(WA_DESK)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(6.dp),
        verticalArrangement = Arrangement.spacedBy(4.dp),
    ) {
        MainWindow(
            vm = vm,
            showEq = showEq,
            showDsp = showDsp,
            showPl = showPl,
            onToggleEq = { showEq = !showEq },
            onToggleDsp = { showDsp = !showDsp },
            onTogglePl = { showPl = !showPl },
            onMinimize = { minimizeToFloating(context) },
        )
        if (showEq) EqWindow(eqMin) { eqMin = !eqMin }
        if (showDsp) DspWindow(dspMin) { dspMin = !dspMin }
        if (showPl) {
            PlaylistWindow(
                songs = songs,
                loaded = loaded,
                granted = granted,
                currentId = ui.mediaId,
                onClick = vm::play,
                onRefresh = vm::loadSongs,
                onRequestPermission = { launcher.launch(requestedPermissions()) },
                minimized = plMin,
                onToggleMinimize = { plMin = !plMin },
                modifier = if (plMin) Modifier else Modifier.weight(1f),
            )
        }
    }
}
