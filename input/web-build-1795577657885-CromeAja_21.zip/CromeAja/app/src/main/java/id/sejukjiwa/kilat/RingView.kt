package id.sejukjiwa.kilat

import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.util.AttributeSet
import android.view.View

/** Cincin progres kecil yang dipasang di belakang ikon unduh. progress < 0 = tidak tentu (berputar). */
class RingView @JvmOverloads constructor(ctx: Context, attrs: AttributeSet? = null) : View(ctx, attrs) {
    private val d = resources.displayMetrics.density
    private val track = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; strokeWidth = 2.5f * d }
    private val arc = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        style = Paint.Style.STROKE; strokeWidth = 2.5f * d; strokeCap = Paint.Cap.ROUND
    }
    private val box = RectF()
    private var color = 0xFF1A73E8.toInt()

    /** 0..1, atau negatif jika ukuran total belum diketahui. */
    var progress = -1f
        set(v) { field = v; invalidate() }

    fun setRingColor(c: Int) {
        color = c
        track.color = (c and 0x00FFFFFF) or 0x44000000
        arc.color = c
        invalidate()
    }

    override fun onDraw(canvas: Canvas) {
        val side = minOf(width, height) - 6f * d
        if (side <= 0f) return
        val cx = width / 2f
        val cy = height / 2f
        box.set(cx - side / 2, cy - side / 2, cx + side / 2, cy + side / 2)
        canvas.drawOval(box, track)
        if (progress < 0f) {
            val start = (SystemClock.uptimeMillis() % 1000L) / 1000f * 360f
            canvas.drawArc(box, start, 100f, false, arc)
            postInvalidateOnAnimation()
        } else {
            canvas.drawArc(box, -90f, 360f * progress.coerceIn(0f, 1f), false, arc)
        }
    }
}
