package id.sejukjiwa.kilat

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.os.Handler
import android.os.Looper
import android.util.LruCache
import java.io.File
import java.net.HttpURLConnection
import java.net.URL
import java.util.concurrent.Executors

/** Logo (favicon) situs untuk daftar bookmark / riwayat / halaman tersimpan. Cache memori + disk. */
object FavIcons {
    private val mem = LruCache<String, Bitmap>(80)
    private val failed = HashSet<String>()
    private val pool = Executors.newFixedThreadPool(3)
    private val main = Handler(Looper.getMainLooper())

    fun load(ctx: Context, host: String, cb: (Bitmap?) -> Unit) {
        mem.get(host)?.let { cb(it); return }
        synchronized(failed) { if (host in failed) { cb(null); return } }
        val app = ctx.applicationContext
        pool.execute {
            var bmp: Bitmap? = null
            try {
                val dir = File(app.cacheDir, "fav")
                dir.mkdirs()
                val f = File(dir, host.replace(Regex("[^A-Za-z0-9.-]"), "_") + ".png")
                if (f.exists() && f.length() > 0) bmp = BitmapFactory.decodeFile(f.path)
                if (bmp == null) {
                    val c = URL("https://www.google.com/s2/favicons?domain=" + java.net.URLEncoder.encode(host, "UTF-8") + "&sz=64")
                        .openConnection() as HttpURLConnection
                    c.connectTimeout = 8000
                    c.readTimeout = 8000
                    try {
                        if (c.responseCode == 200) {
                            val bytes = c.inputStream.use { it.readBytes() }
                            bmp = BitmapFactory.decodeByteArray(bytes, 0, bytes.size)
                            if (bmp != null) f.writeBytes(bytes)
                        }
                    } finally {
                        c.disconnect()
                    }
                }
            } catch (e: Exception) {
                // abaikan: pakai huruf awal
            }
            if (bmp != null) mem.put(host, bmp) else synchronized(failed) { failed.add(host) }
            main.post { cb(bmp) }
        }
    }
}
