package com.example.pemutarmusik

import android.app.Service
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.PixelFormat
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.StateListDrawable
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.provider.Settings
import android.text.TextUtils
import android.util.TypedValue
import android.view.Gravity
import android.view.MotionEvent
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.ImageButton
import android.widget.LinearLayout
import android.widget.TextView
import androidx.core.content.ContextCompat
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer

/**
 * Mini player melayang: tampil di atas semua aplikasi saat MP3 di-minimize.
 * Isi: judul berjalan, waktu, grafik audio spectrum berwarna, tombol sebelumnya / putar / jeda / henti / berikutnya,
 * tombol buka aplikasi dan tutup. Selalu di tengah layar, bisa digeser naik/turun lewat layar LCD-nya. Butuh izin "Tampil di atas aplikasi lain".
 */
class FloatingPlayerService : Service() {

    private lateinit var wm: WindowManager
    private var root: View? = null
    private var controller: MediaController? = null
    private val handler = Handler(Looper.getMainLooper())

    private lateinit var titleView: TextView
    private lateinit var timeView: TextView
    private lateinit var spectrum: SpectrumOverlayView
    private lateinit var playBtn: ImageButton
    private lateinit var pauseBtn: ImageButton
    private lateinit var stopBtn: TextView

    private val ticker = object : Runnable {
        override fun run() {
            refresh()
            handler.postDelayed(this, 500)
        }
    }

    private val frameTicker = object : Runnable {
        override fun run() {
            spectrum.step(controller?.isPlaying == true)
            handler.postDelayed(this, 40)
        }
    }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        if (!Settings.canDrawOverlays(this)) {
            stopSelf()
            return
        }
        Skin.init(this)
        wm = getSystemService(WINDOW_SERVICE) as WindowManager
        buildView()
        connectController()
        handler.post(ticker)
        handler.post(frameTicker)
    }

    private fun dp(v: Float): Int =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v, resources.displayMetrics).toInt()

    private fun silver(radius: Float): GradientDrawable = GradientDrawable(
        GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFE6EAF2.toInt(), 0xFF9AA4BA.toInt())
    ).apply {
        cornerRadius = dp(radius).toFloat()
        setStroke(dp(1.5f), 0xFF16244A.toInt())
    }

    private fun roundButton(pressedColor: Int, size: Int): StateListDrawable {
        fun lit() = GradientDrawable().apply {
            shape = GradientDrawable.OVAL
            setColor(pressedColor)
            setStroke(dp(1.5f), 0xFF16244A.toInt())
            setSize(size, size)
        }
        val normal = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM, intArrayOf(0xFFF1F4FA.toInt(), 0xFFA9B3C9.toInt())
        ).apply { shape = GradientDrawable.OVAL; setStroke(dp(1.5f), 0xFF16244A.toInt()); setSize(size, size) }
        return StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), lit())
            addState(intArrayOf(android.R.attr.state_selected), lit())   // status aktif (play / pause / stop)
            addState(intArrayOf(), normal)
        }
    }

    private fun buildView() {
        val lcd = 0xFF173E86.toInt()
        val ink = 0xFF1B2A55.toInt()
        val accent = Skin.p.c3.toArgbInt()

        val box = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(5f), dp(4f), dp(5f), dp(4f))
            background = silver(12f)
        }

        // ---- layar LCD: judul + waktu (kiri), spectrum (kanan). Area ini dipakai untuk menggeser. ----
        val lcdBox = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
            setPadding(dp(8f), dp(3f), dp(8f), dp(3f))
            background = GradientDrawable().apply {
                setColor(lcd)
                cornerRadius = dp(8f).toFloat()
                setStroke(dp(1f), 0xFF0B1B44.toInt())
            }
        }
        val info = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        titleView = TextView(this).apply {
            setTextColor(0xFFEAF2FF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 10f)
            typeface = Typeface.MONOSPACE
            setSingleLine(true)
            ellipsize = TextUtils.TruncateAt.MARQUEE
            marqueeRepeatLimit = -1
            isSelected = true
            text = "MP3"
        }
        timeView = TextView(this).apply {
            setTextColor(0xFFFFFFFF.toInt())
            setTextSize(TypedValue.COMPLEX_UNIT_SP, 16f)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            text = "00:00"
        }
        info.addView(titleView, LinearLayout.LayoutParams(dp(150f), LinearLayout.LayoutParams.WRAP_CONTENT))
        info.addView(timeView)
        lcdBox.addView(info)

        spectrum = SpectrumOverlayView(this)
        lcdBox.addView(spectrum, LinearLayout.LayoutParams(dp(150f), dp(30f)).apply { leftMargin = dp(8f) })
        box.addView(lcdBox, LinearLayout.LayoutParams(LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT))

        // ---- tombol ----
        val row = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        fun imgBtn(res: Int, desc: String, px: Int, color: Int, onClick: () -> Unit) = ImageButton(this).apply {
            setImageResource(res)
            setColorFilter(ink)
            contentDescription = desc
            background = roundButton(color, px)
            scaleType = android.widget.ImageView.ScaleType.CENTER_INSIDE
            setPadding(dp(6f), dp(6f), dp(6f), dp(6f))
            setOnClickListener { onClick() }
        }
        fun txtBtn(label: String, desc: String, px: Int, color: Int, size: Float = 13f, onClick: () -> Unit) = TextView(this).apply {
            text = label
            contentDescription = desc
            gravity = Gravity.CENTER
            setTextColor(ink)
            setTextSize(TypedValue.COMPLEX_UNIT_SP, size)
            typeface = Typeface.create(Typeface.MONOSPACE, Typeface.BOLD)
            background = roundButton(color, px)
            setOnClickListener { onClick() }
        }

        val btn = dp(32f)
        fun lp(px: Int, left: Int = 4) = LinearLayout.LayoutParams(px, px).apply { leftMargin = dp(left.toFloat()) }
        val p = Skin.p
        val cPrev = p.c1.toArgbInt()
        val cPlay = p.c2.toArgbInt()
        val cPause = p.c4.toArgbInt()
        val cStop = p.c3.toArgbInt()

        // 5 tombol: sebelumnya, putar, jeda, henti, berikutnya (warna saat ditekan mengikuti tema)
        row.addView(imgBtn(android.R.drawable.ic_media_previous, "Sebelumnya", btn, cPrev) { controller?.seekToPrevious() }, lp(btn, 0))
        playBtn = imgBtn(android.R.drawable.ic_media_play, "Putar", btn, cPlay) {
            controller?.let { if (it.currentMediaItem != null) it.play() }
        }
        row.addView(playBtn, lp(btn))
        pauseBtn = imgBtn(android.R.drawable.ic_media_pause, "Jeda", btn, cPause) { controller?.pause() }
        row.addView(pauseBtn, lp(btn))
        stopBtn = txtBtn("■", "Henti", btn, cStop, 14f) {
            controller?.let { it.pause(); it.seekTo(0L) }
        }
        row.addView(stopBtn, lp(btn))
        row.addView(imgBtn(android.R.drawable.ic_media_next, "Berikutnya", btn, cPrev) { controller?.seekToNextMediaItem() }, lp(btn))
        row.addView(View(this), LinearLayout.LayoutParams(0, 1, 1f))
        row.addView(txtBtn("□", "Buka aplikasi", btn, accent) { restoreApp() }, lp(btn, 0))
        row.addView(txtBtn("X", "Tutup", btn, accent) { stopSelf() }, lp(btn))
        box.addView(row, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT).apply { topMargin = dp(4f) })

        val params = WindowManager.LayoutParams(
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.WRAP_CONTENT,
            WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
            PixelFormat.TRANSLUCENT,
        ).apply {
            gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL   // selalu di tengah layar
            x = 0
            y = dp(120f)
        }

        // geser naik/turun dengan menyentuh layar LCD
        var startY = 0
        var touchX = 0f
        var touchY = 0f
        lcdBox.setOnTouchListener { _, e ->
            when (e.action) {
                MotionEvent.ACTION_DOWN -> {
                    startY = params.y
                    touchX = e.rawX; touchY = e.rawY
                    true
                }
                MotionEvent.ACTION_MOVE -> {
                    // hanya naik/turun; posisi horizontal tetap di tengah
                    params.y = (startY + (e.rawY - touchY).toInt()).coerceAtLeast(0)
                    root?.let { wm.updateViewLayout(it, params) }
                    true
                }
                MotionEvent.ACTION_UP -> true
                else -> false
            }
        }

        root = box
        wm.addView(box, params)
    }

    private fun androidx.compose.ui.graphics.Color.toArgbInt(): Int =
        Color.argb((alpha * 255).toInt(), (red * 255).toInt(), (green * 255).toInt(), (blue * 255).toInt())

    private fun connectController() {
        val token = SessionToken(this, ComponentName(this, PlaybackService::class.java))
        val future = MediaController.Builder(this, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = refresh()
                })
                refresh()
            } catch (e: Exception) {
                // abaikan: mini player tetap tampil tapi tombol tidak aktif
            }
        }, ContextCompat.getMainExecutor(this))
    }

    private fun refresh() {
        val c = controller ?: return
        val md = c.currentMediaItem?.mediaMetadata
        val title = md?.title?.toString()
        if (title != null) {
            titleView.text = "${md?.artist ?: ""} - $title    "
        }
        val pos = c.currentPosition.coerceAtLeast(0L) / 1000
        timeView.text = "%02d:%02d".format(pos / 60, pos % 60)
        val playing = c.isPlaying
        val stopped = !playing && pos <= 0L
        playBtn.isSelected = playing
        pauseBtn.isSelected = !playing && !stopped
        stopBtn.isSelected = stopped
    }

    private fun restoreApp() {
        val intent = Intent(this, MainActivity::class.java).addFlags(
            Intent.FLAG_ACTIVITY_NEW_TASK or Intent.FLAG_ACTIVITY_REORDER_TO_FRONT or Intent.FLAG_ACTIVITY_SINGLE_TOP
        )
        startActivity(intent)
        stopSelf()
    }

    override fun onDestroy() {
        handler.removeCallbacks(ticker)
        handler.removeCallbacks(frameTicker)
        root?.let { runCatching { wm.removeView(it) } }
        root = null
        controller?.release()
        controller = null
        super.onDestroy()
    }
}

/** Grafik audio spectrum 19 bar bersegmen + penanda puncak, warna mengikuti palet LED yang dipilih. */
class SpectrumOverlayView(context: Context) : View(context) {

    private val analyzer = SpectrumAnalyzer(AudioEngine.processor)
    private val bars = FloatArray(SpectrumAnalyzer.BARS)
    private val peaks = FloatArray(SpectrumAnalyzer.BARS)
    private val paint = Paint(Paint.ANTI_ALIAS_FLAG)
    private var frame = 0

    fun step(playing: Boolean) {
        val idle = !playing && bars.all { it <= 0f } && peaks.all { it <= 0f }
        if (idle) return
        val fresh = if (playing) analyzer.compute() else FloatArray(bars.size)
        for (i in bars.indices) {
            bars[i] = maxOf(fresh[i], bars[i] - 0.07f)
            peaks[i] = maxOf(bars[i], maxOf(peaks[i] - 0.015f, 0f))
        }
        frame++
        invalidate()
    }

    private fun mix(a: androidx.compose.ui.graphics.Color, b: androidx.compose.ui.graphics.Color, t: Float): Int {
        fun ch(x: Float, y: Float) = ((x + (y - x) * t) * 255).toInt().coerceIn(0, 255)
        return Color.rgb(ch(a.red, b.red), ch(a.green, b.green), ch(a.blue, b.blue))
    }

    override fun onDraw(canvas: Canvas) {
        val n = bars.size
        val gap = 1.5f * resources.displayMetrics.density
        val w = (width - gap * (n - 1)) / n
        val segs = 12
        val segH = height.toFloat() / segs
        val low = Skin.p.specLow
        val high = Skin.p.specHigh
        for (i in 0 until n) {
            val x = i * (w + gap)
            val lit = (bars[i] * segs).toInt()
            for (s in 0 until lit) {
                paint.color = mix(low, high, s / (segs - 1f))
                val y = height - (s + 1) * segH
                canvas.drawRoundRect(x, y + 0.5f, x + w, y + segH - 0.5f, 1.5f, 1.5f, paint)
            }
            if (peaks[i] > 0.02f) {
                val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
                paint.color = Color.WHITE
                val y = height - (pk + 1) * segH
                canvas.drawRoundRect(x, y + 0.5f, x + w, y + segH - 0.5f, 1.5f, 1.5f, paint)
            }
        }
    }
}
