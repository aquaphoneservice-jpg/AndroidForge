# MP3 (Android) - skin Ocean Blue

Jendela: PEMUTAR MUSIK (tombol minimize = mini player melayang), EQUALIZER 10 BAND, DSP / POWER AMP, PLAYLIST.

## Fitur
- Acak (shuffle) dan Ulang (mati / semua / 1 lagu), masing-masing dengan LED.
- Skin permanen OCEAN (tombol ganti skin dihapus).
- Playlist: tekan lama lagu -> Pindah ke album, Hapus lagu, Rincian (+ Naikkan/Turunkan urutan, Keluarkan dari album saat di dalam album).
- Album = playlist buatan sendiri: tombol "+" buat album, tekan lama nama album -> Ganti nama / Hapus album,
  tombol TAMBAH untuk memilih banyak lagu sesuai urutan ketukan.
- Suara: auto headroom, limiter look-ahead, bass guard otomatis, power amp 0..+12 dB.

## Cara pakai
1. Android Studio terbaru, File > Open > pilih folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging), Run. Beri izin akses musik.
Min Android 7.0 (API 24).

## Catatan v6
- Nama aplikasi: MP3, ikon baru gradasi violet-magenta-coral (adaptive icon).
- Tombol utama: sebelumnya / putar / jeda / henti / berikutnya (5 tombol, juga di mini player; tombol sesuai status tetap menyala, mini player selalu di tengah dan hanya digeser naik/turun, masing-masing menyala warna tema saat ditekan). Tombol acak dan ulang ada di baris bawah bersama EQ/DSP/PL; 5 tombol transport di tengah. Font playlist diperbesar.
- Playlist punya kolom cari di bagian bawah.
- Mini player melayang punya grafik spectrum warna.
