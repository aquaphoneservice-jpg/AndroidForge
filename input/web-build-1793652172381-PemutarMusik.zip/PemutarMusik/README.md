# Pemutar Musik (Android)

Pemutar MP3 sederhana + equalizer 10 band + Bass Guard (bass otomatis ditekan kalau berlebihan).

## Cara pakai
1. Install Android Studio (versi terbaru), lalu File > Open > pilih folder ini.
2. Tunggu Gradle sync selesai (butuh internet pertama kali).
3. Colok HP (USB debugging aktif) lalu klik Run. Atau Build > Build APK(s).
4. Beri izin akses musik saat diminta.

Min Android 7.0 (API 24).
