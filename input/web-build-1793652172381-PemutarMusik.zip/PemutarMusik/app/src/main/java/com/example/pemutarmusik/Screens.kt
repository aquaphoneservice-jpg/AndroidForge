package com.example.pemutarmusik

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.MusicNote
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.SkipNext
import androidx.compose.material.icons.filled.SkipPrevious
import androidx.compose.material3.Card
import androidx.compose.material3.FilledIconButton
import androidx.compose.material3.FilterChip
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Slider
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.TransformOrigin
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.layout.layout
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.Constraints
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.EqAudioProcessor
import com.example.pemutarmusik.audio.Presets
import kotlinx.coroutines.delay
import kotlin.math.roundToInt

fun formatTime(ms: Long): String {
    val s = (ms / 1000).coerceAtLeast(0)
    return "%d:%02d".format(s / 60, s % 60)
}

// ---------------------------------------------------------------- Daftar lagu

@Composable
fun SongListScreen(
    songs: List<Song>,
    loaded: Boolean,
    currentId: String?,
    onClick: (Song) -> Unit,
    modifier: Modifier = Modifier,
) {
    if (loaded && songs.isEmpty()) {
        Box(modifier.fillMaxSize().padding(24.dp), contentAlignment = Alignment.Center) {
            Text("Tidak ada file MP3 ditemukan di penyimpanan.", textAlign = TextAlign.Center)
        }
    } else {
        LazyColumn(modifier.fillMaxSize()) {
            items(songs, key = { it.id }) { song ->
                val selected = song.id.toString() == currentId
                Row(
                    Modifier
                        .fillMaxWidth()
                        .background(if (selected) MaterialTheme.colorScheme.secondaryContainer else Color.Transparent)
                        .clickable { onClick(song) }
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Icon(
                        Icons.Filled.MusicNote,
                        contentDescription = null,
                        tint = if (selected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    Spacer(Modifier.width(16.dp))
                    Column(Modifier.weight(1f)) {
                        Text(
                            song.title,
                            style = MaterialTheme.typography.bodyLarge,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                        Text(
                            song.artist,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis,
                        )
                    }
                    Spacer(Modifier.width(12.dp))
                    Text(
                        formatTime(song.durationMs),
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                }
            }
        }
    }
}

// ---------------------------------------------------------------- Bar pemutar

@Composable
fun PlayerBar(
    ui: PlayerUi,
    onPrev: () -> Unit,
    onToggle: () -> Unit,
    onNext: () -> Unit,
    onSeek: (Long) -> Unit,
) {
    var drag by remember { mutableStateOf<Float?>(null) }
    val fraction = if (ui.durationMs > 0) (ui.positionMs.toFloat() / ui.durationMs).coerceIn(0f, 1f) else 0f
    val shown = drag ?: fraction

    Surface(tonalElevation = 3.dp, shadowElevation = 6.dp) {
        Column(
            Modifier
                .navigationBarsPadding()
                .padding(horizontal = 16.dp, vertical = 8.dp)
        ) {
            Text(
                ui.title ?: "",
                style = MaterialTheme.typography.titleSmall,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Text(
                ui.artist ?: "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                maxLines = 1,
                overflow = TextOverflow.Ellipsis,
            )
            Slider(
                value = shown,
                onValueChange = { drag = it },
                onValueChangeFinished = {
                    drag?.let { onSeek((it * ui.durationMs).toLong()) }
                    drag = null
                },
            )
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(formatTime((shown * ui.durationMs).toLong()), style = MaterialTheme.typography.labelSmall)
                Text(formatTime(ui.durationMs), style = MaterialTheme.typography.labelSmall)
            }
            Row(
                Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.Center,
                verticalAlignment = Alignment.CenterVertically,
            ) {
                IconButton(onClick = onPrev) { Icon(Icons.Filled.SkipPrevious, contentDescription = "Sebelumnya") }
                Spacer(Modifier.width(16.dp))
                FilledIconButton(onClick = onToggle, modifier = Modifier.size(56.dp)) {
                    Icon(
                        if (ui.isPlaying) Icons.Filled.Pause else Icons.Filled.PlayArrow,
                        contentDescription = if (ui.isPlaying) "Jeda" else "Putar",
                    )
                }
                Spacer(Modifier.width(16.dp))
                IconButton(onClick = onNext) { Icon(Icons.Filled.SkipNext, contentDescription = "Berikutnya") }
            }
        }
    }
}

// ---------------------------------------------------------------- Equalizer

private val FREQ_LABELS = listOf("31", "62", "125", "250", "500", "1k", "2k", "4k", "8k", "16k")

private fun formatDb(v: Float): String =
    if (v == 0f) "0" else if (v % 1f == 0f) "%+d".format(v.toInt()) else "%+.1f".format(v)

@Composable
fun EqualizerScreen(modifier: Modifier = Modifier) {
    val s by AudioEngine.settings.collectAsState()

    // Seberapa dalam bass sedang ditekan guard (dibaca ~10x per detik)
    var reduction by remember { mutableFloatStateOf(0f) }
    LaunchedEffect(Unit) {
        while (true) {
            reduction = AudioEngine.processor.guardReductionDb
            delay(100)
        }
    }

    Column(
        modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp),
    ) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text("Equalizer 10 band", style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
            Switch(checked = s.enabled, onCheckedChange = { v -> AudioEngine.update { it.copy(enabled = v) } })
        }

        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Presets.all.forEach { (name, g) ->
                FilterChip(
                    selected = s.gains == g,
                    onClick = { AudioEngine.update { it.copy(gains = g) } },
                    label = { Text(name) },
                )
            }
        }

        Row(Modifier.fillMaxWidth()) {
            for (i in 0 until EqAudioProcessor.BAND_COUNT) {
                Column(Modifier.weight(1f), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text(formatDb(s.gains[i]), fontSize = 10.sp)
                    VerticalSlider(
                        value = s.gains[i],
                        onValueChange = { v ->
                            val snapped = (v * 2f).roundToInt() / 2f
                            AudioEngine.update { st ->
                                st.copy(gains = st.gains.toMutableList().also { it[i] = snapped })
                            }
                        },
                        valueRange = -EqAudioProcessor.MAX_GAIN_DB..EqAudioProcessor.MAX_GAIN_DB,
                        enabled = s.enabled,
                        modifier = Modifier.fillMaxWidth().height(180.dp),
                    )
                    Text(FREQ_LABELS[i], fontSize = 10.sp)
                }
            }
        }
        Text(
            "Satuan dB. Frekuensi dalam Hz.",
            style = MaterialTheme.typography.labelSmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant,
        )

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Bass otomatis (anti-geber)", style = MaterialTheme.typography.titleSmall)
                        Text(
                            "Kalau bass terlalu kuat, otomatis ditekan supaya tidak pecah.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                        )
                    }
                    Switch(
                        checked = s.guardEnabled,
                        onCheckedChange = { v -> AudioEngine.update { it.copy(guardEnabled = v) } },
                    )
                }
                if (s.guardEnabled) {
                    Text("Batas bass: %.0f dB".format(s.guardThresholdDb), style = MaterialTheme.typography.bodyMedium)
                    Slider(
                        value = s.guardThresholdDb,
                        onValueChange = { v -> AudioEngine.update { it.copy(guardThresholdDb = v.roundToInt().toFloat()) } },
                        valueRange = -20f..-2f,
                    )
                    Text(
                        "Geser ke kiri = lebih ketat (bass lebih cepat ditekan).",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                    )
                    LinearProgressIndicator(
                        progress = { (reduction / 18f).coerceIn(0f, 1f) },
                        modifier = Modifier.fillMaxWidth(),
                    )
                    Text(
                        if (reduction > 0.5f) "Bass ditekan %.1f dB".format(reduction) else "Bass aman",
                        style = MaterialTheme.typography.bodySmall,
                    )
                }
            }
        }
    }
}

/** Slider vertikal: Slider biasa yang diputar 270 derajat. Nilai kecil di bawah, besar di atas. */
@Composable
fun VerticalSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    valueRange: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    enabled: Boolean = true,
) {
    Slider(
        value = value,
        onValueChange = onValueChange,
        valueRange = valueRange,
        enabled = enabled,
        modifier = modifier
            .graphicsLayer {
                rotationZ = 270f
                transformOrigin = TransformOrigin(0f, 0f)
            }
            .layout { measurable, constraints ->
                val placeable = measurable.measure(
                    Constraints(
                        minWidth = constraints.minHeight,
                        maxWidth = constraints.maxHeight,
                        minHeight = constraints.minWidth,
                        maxHeight = constraints.maxWidth,
                    )
                )
                layout(placeable.height, placeable.width) {
                    placeable.place(-placeable.width, 0)
                }
            },
    )
}
