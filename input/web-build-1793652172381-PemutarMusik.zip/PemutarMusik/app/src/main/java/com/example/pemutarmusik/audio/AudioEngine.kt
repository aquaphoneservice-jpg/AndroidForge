package com.example.pemutarmusik.audio

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqSettings(
    val enabled: Boolean = true,
    val gains: List<Float> = List(EqAudioProcessor.BAND_COUNT) { 0f },
    val guardEnabled: Boolean = true,
    val guardThresholdDb: Float = -8f,
)

object Presets {
    val all: List<Pair<String, List<Float>>> = listOf(
        "Flat" to List(10) { 0f },
        "Bass+" to listOf(5f, 4f, 3f, 1f, 0f, 0f, 0f, 0f, 0f, 0f),
        "Rock" to listOf(4f, 3f, 2f, 0f, -1f, -1f, 1f, 3f, 4f, 4f),
        "Vokal" to listOf(-2f, -2f, -1f, 1f, 3f, 3f, 3f, 2f, 0f, -1f),
    )
}

/**
 * Satu-satunya pemegang equalizer: dipakai bersama oleh PlaybackService (yang memutar audio)
 * dan UI (yang mengubah pengaturan). Pengaturan disimpan otomatis.
 */
object AudioEngine {
    val processor = EqAudioProcessor()

    private val _settings = MutableStateFlow(EqSettings())
    val settings: StateFlow<EqSettings> = _settings.asStateFlow()

    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("equalizer", Context.MODE_PRIVATE)
        prefs = p

        val saved = p.getString("gains", null)
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == EqAudioProcessor.BAND_COUNT }
        val loaded = EqSettings(
            enabled = p.getBoolean("enabled", true),
            gains = saved ?: List(EqAudioProcessor.BAND_COUNT) { 0f },
            guardEnabled = p.getBoolean("guard", true),
            guardThresholdDb = p.getFloat("threshold", -8f),
        )
        _settings.value = loaded
        apply(loaded)
    }

    fun update(block: (EqSettings) -> EqSettings) {
        val next = block(_settings.value)
        _settings.value = next
        apply(next)
        save(next)
    }

    private fun apply(s: EqSettings) {
        processor.eqEnabled = s.enabled
        processor.guardEnabled = s.guardEnabled
        processor.guardThresholdDb = s.guardThresholdDb
        processor.setGains(s.gains.toFloatArray())
    }

    private fun save(s: EqSettings) {
        prefs?.edit()
            ?.putBoolean("enabled", s.enabled)
            ?.putString("gains", s.gains.joinToString(","))
            ?.putBoolean("guard", s.guardEnabled)
            ?.putFloat("threshold", s.guardThresholdDb)
            ?.apply()
    }
}
