package com.example.pemutarmusik

import android.app.Application
import android.content.ComponentName
import androidx.core.content.ContextCompat
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import androidx.media3.common.C
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

data class PlayerUi(
    val mediaId: String? = null,
    val title: String? = null,
    val artist: String? = null,
    val isPlaying: Boolean = false,
    val positionMs: Long = 0,
    val durationMs: Long = 0,
)

class PlayerViewModel(app: Application) : AndroidViewModel(app) {

    private val _songs = MutableStateFlow<List<Song>>(emptyList())
    val songs: StateFlow<List<Song>> = _songs.asStateFlow()

    private val _loaded = MutableStateFlow(false)
    val loaded: StateFlow<Boolean> = _loaded.asStateFlow()

    private val _ui = MutableStateFlow(PlayerUi())
    val ui: StateFlow<PlayerUi> = _ui.asStateFlow()

    private var controller: MediaController? = null
    private var mediaItems: List<MediaItem> = emptyList()

    init {
        connectToService()
        viewModelScope.launch {
            // Perbarui posisi lagu tiap 0,5 detik saat sedang diputar
            while (true) {
                delay(500)
                val c = controller ?: continue
                if (c.isPlaying) _ui.update { it.copy(positionMs = c.currentPosition) }
            }
        }
    }

    private fun connectToService() {
        val context = getApplication<Application>()
        val token = SessionToken(context, ComponentName(context, PlaybackService::class.java))
        val future = MediaController.Builder(context, token).buildAsync()
        future.addListener({
            try {
                val c = future.get()
                controller = c
                c.addListener(object : Player.Listener {
                    override fun onEvents(player: Player, events: Player.Events) = syncFromPlayer()
                })
                syncFromPlayer()
            } catch (e: Exception) {
                // Gagal konek ke service: pemutar tidak tersedia
            }
        }, ContextCompat.getMainExecutor(context))
    }

    private fun syncFromPlayer() {
        val c = controller ?: return
        val item = c.currentMediaItem
        _ui.value = PlayerUi(
            mediaId = item?.mediaId,
            title = item?.mediaMetadata?.title?.toString(),
            artist = item?.mediaMetadata?.artist?.toString(),
            isPlaying = c.isPlaying,
            positionMs = c.currentPosition.coerceAtLeast(0L),
            durationMs = c.duration.takeIf { it != C.TIME_UNSET } ?: 0L,
        )
    }

    fun loadSongs() {
        viewModelScope.launch {
            val list = try {
                withContext(Dispatchers.IO) { MusicRepository.loadMp3(getApplication()) }
            } catch (e: SecurityException) {
                emptyList()
            }
            _songs.value = list
            mediaItems = list.map { it.toMediaItem() }
            _loaded.value = true
        }
    }

    fun play(song: Song) {
        val c = controller ?: return
        val index = _songs.value.indexOfFirst { it.id == song.id }
        if (index < 0) return
        c.setMediaItems(mediaItems, index, 0L)
        c.prepare()
        c.play()
    }

    fun togglePlayPause() {
        val c = controller ?: return
        if (c.isPlaying) c.pause() else c.play()
    }

    fun next() {
        controller?.seekToNextMediaItem()
    }

    fun previous() {
        controller?.seekToPrevious()
    }

    fun seekTo(positionMs: Long) {
        controller?.seekTo(positionMs)
    }

    override fun onCleared() {
        controller?.release()
        controller = null
        super.onCleared()
    }
}
