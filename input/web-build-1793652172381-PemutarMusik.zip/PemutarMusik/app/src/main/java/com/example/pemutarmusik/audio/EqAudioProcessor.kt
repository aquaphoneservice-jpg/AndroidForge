package com.example.pemutarmusik.audio

import androidx.media3.common.C
import androidx.media3.common.audio.AudioProcessor
import androidx.media3.common.audio.BaseAudioProcessor
import java.nio.ByteBuffer
import java.nio.ByteOrder
import kotlin.math.PI
import kotlin.math.abs
import kotlin.math.cos
import kotlin.math.exp
import kotlin.math.log10
import kotlin.math.max
import kotlin.math.min
import kotlin.math.pow
import kotlin.math.roundToInt
import kotlin.math.sign
import kotlin.math.sin
import kotlin.math.tanh

/**
 * Equalizer 10 band + "Bass Guard" (penekan bass otomatis) + pembatas puncak.
 *
 * Dipasang di rantai audio ExoPlayer, jadi bekerja di semua HP
 * (tidak bergantung pada android.media.audiofx.Equalizer yang biasanya cuma 5 band).
 *
 * Alur per sample:
 *   1. 10 filter peaking (biquad) -> EQ
 *   2. Bass dipisah dengan low-pass ~120 Hz, level-nya dipantau (envelope follower)
 *   3. Kalau level bass melewati batas, bass dikurangi otomatis (rasio 4:1, maks 18 dB)
 *   4. Soft limiter di akhir supaya tidak pernah clipping / pecah
 */
class EqAudioProcessor : BaseAudioProcessor() {

    companion object {
        const val BAND_COUNT = 10
        val BAND_FREQS = floatArrayOf(31.25f, 62.5f, 125f, 250f, 500f, 1000f, 2000f, 4000f, 8000f, 16000f)
        const val MAX_GAIN_DB = 12f

        private const val MAX_CHANNELS = 8
        private const val BAND_Q = 1.41            // ~1 oktaf per band
        private const val BASS_SPLIT_HZ = 120.0    // batas "bass" untuk pemantauan
        private const val RATIO = 4.0              // kompresi bass saat melewati batas
        private const val MAX_REDUCTION_DB = 18.0
        private const val CONTROL_INTERVAL = 32    // hitung gain guard tiap N frame
        private const val LIMITER_KNEE = 0.9
    }

    // ---- Pengaturan dari UI (thread lain) ----
    @Volatile private var gains = FloatArray(BAND_COUNT)
    @Volatile private var gainsDirty = true
    @Volatile var eqEnabled = true
    @Volatile var guardEnabled = true
    @Volatile var guardThresholdDb = -8f

    /** Berapa dB bass sedang ditekan oleh guard (0 = aman). Dibaca UI. */
    @Volatile
    var guardReductionDb: Float = 0f
        private set

    // ---- State thread audio ----
    private var channels = 0
    private var sampleRate = 44100
    private val coef = DoubleArray(BAND_COUNT * 5)   // b0 b1 b2 a1 a2 per band
    private var z = DoubleArray(0)                   // [channel][band][2]
    private val lpCoef = DoubleArray(5)
    private var lpZ = DoubleArray(0)                 // [channel][2]
    private var env = 0.0
    private var guardGain = 1.0
    private var targetGain = 1.0
    private var controlCounter = 0
    private var attackCoef = 0.0
    private var releaseCoef = 0.0

    fun setGains(newGains: FloatArray) {
        gains = newGains.copyOf(BAND_COUNT)
        gainsDirty = true
    }

    override fun onConfigure(inputAudioFormat: AudioProcessor.AudioFormat): AudioProcessor.AudioFormat {
        // Hanya PCM 16-bit (hasil decode MP3). Selain itu: lewati saja.
        if (inputAudioFormat.encoding != C.ENCODING_PCM_16BIT ||
            inputAudioFormat.channelCount !in 1..MAX_CHANNELS
        ) {
            return AudioProcessor.AudioFormat.NOT_SET
        }
        return inputAudioFormat
    }

    override fun onFlush() {
        channels = inputAudioFormat.channelCount
        sampleRate = inputAudioFormat.sampleRate
        z = DoubleArray(channels * BAND_COUNT * 2)
        lpZ = DoubleArray(channels * 2)
        env = 0.0
        guardGain = 1.0
        targetGain = 1.0
        controlCounter = 0
        attackCoef = 1.0 - exp(-1.0 / (0.003 * sampleRate))   // 3 ms
        releaseCoef = 1.0 - exp(-1.0 / (0.150 * sampleRate))  // 150 ms
        gainsDirty = false
        computeCoefs()
        guardReductionDb = 0f
    }

    override fun queueInput(inputBuffer: ByteBuffer) {
        val size = inputBuffer.remaining()
        if (size == 0) return

        val out = replaceOutputBuffer(size).order(ByteOrder.LITTLE_ENDIAN)
        val input = inputBuffer.slice().order(ByteOrder.LITTLE_ENDIAN)
        inputBuffer.position(inputBuffer.limit())

        val doEq = eqEnabled
        val doGuard = guardEnabled
        if (channels == 0 || (!doEq && !doGuard)) {
            out.put(input)
            out.flip()
            return
        }

        if (gainsDirty) {
            gainsDirty = false
            computeCoefs()
        }

        val ch = channels
        val frames = size / (2 * ch)
        val thresholdDb = guardThresholdDb.toDouble()
        val inv = 1.0 / 32768.0

        for (f in 0 until frames) {
            var framePeakBass = 0.0

            for (c in 0 until ch) {
                var x = input.getShort().toDouble() * inv

                // 1) Equalizer 10 band
                if (doEq) {
                    var zi = c * BAND_COUNT * 2
                    var ci = 0
                    for (b in 0 until BAND_COUNT) {
                        val y = coef[ci] * x + z[zi]
                        z[zi] = coef[ci + 1] * x - coef[ci + 3] * y + z[zi + 1]
                        z[zi + 1] = coef[ci + 2] * x - coef[ci + 4] * y
                        x = y
                        zi += 2
                        ci += 5
                    }
                }

                // 2) Pisahkan bass, pantau levelnya, lalu kurangi bila perlu
                if (doGuard) {
                    val li = c * 2
                    val bass = lpCoef[0] * x + lpZ[li]
                    lpZ[li] = lpCoef[1] * x - lpCoef[3] * bass + lpZ[li + 1]
                    lpZ[li + 1] = lpCoef[2] * x - lpCoef[4] * bass
                    val ab = abs(bass)
                    if (ab > framePeakBass) framePeakBass = ab
                    x -= (1.0 - guardGain) * bass
                }

                // 3) Soft limiter: tidak pernah melewati +-1.0
                val ax = abs(x)
                if (ax > LIMITER_KNEE) {
                    val room = 1.0 - LIMITER_KNEE
                    x = sign(x) * (LIMITER_KNEE + room * tanh((ax - LIMITER_KNEE) / room))
                }

                out.putShort((x * 32767.0).roundToInt().coerceIn(-32768, 32767).toShort())
            }

            if (doGuard) {
                env += (if (framePeakBass > env) attackCoef else releaseCoef) * (framePeakBass - env)
                if (++controlCounter >= CONTROL_INTERVAL) {
                    controlCounter = 0
                    val envDb = 20.0 * log10(max(env, 1e-6))
                    val over = envDb - thresholdDb
                    targetGain = if (over > 0.0) {
                        val reduction = min(over * (1.0 - 1.0 / RATIO), MAX_REDUCTION_DB)
                        10.0.pow(-reduction / 20.0)
                    } else {
                        1.0
                    }
                }
                guardGain += (targetGain - guardGain) * 0.02
            }
        }

        // Sisa byte (seharusnya tidak ada) disalin apa adanya
        while (input.hasRemaining()) out.put(input.get())
        out.flip()

        if (doGuard) {
            guardReductionDb = (-20.0 * log10(max(guardGain, 1e-6))).toFloat()
        } else {
            guardGain = 1.0
            targetGain = 1.0
            env = 0.0
            guardReductionDb = 0f
        }
    }

    /** Hitung ulang koefisien (RBJ Audio EQ Cookbook). Dipanggil di thread audio. */
    private fun computeCoefs() {
        val g = gains
        for (b in 0 until BAND_COUNT) {
            val f = BAND_FREQS[b].toDouble()
            val o = b * 5
            val db = g[b].toDouble()
            if (abs(db) < 0.01 || f >= sampleRate * 0.45) {
                coef[o] = 1.0
                coef[o + 1] = 0.0
                coef[o + 2] = 0.0
                coef[o + 3] = 0.0
                coef[o + 4] = 0.0
                continue
            }
            val a = 10.0.pow(db / 40.0)
            val w0 = 2.0 * PI * f / sampleRate
            val cosW = cos(w0)
            val alpha = sin(w0) / (2.0 * BAND_Q)
            val a0 = 1.0 + alpha / a
            coef[o] = (1.0 + alpha * a) / a0
            coef[o + 1] = (-2.0 * cosW) / a0
            coef[o + 2] = (1.0 - alpha * a) / a0
            coef[o + 3] = (-2.0 * cosW) / a0
            coef[o + 4] = (1.0 - alpha / a) / a0
        }

        // Low-pass Butterworth orde 2 untuk pemantau bass
        val w0 = 2.0 * PI * BASS_SPLIT_HZ / sampleRate
        val cosW = cos(w0)
        val alpha = sin(w0) / (2.0 * 0.70710678)
        val a0 = 1.0 + alpha
        lpCoef[0] = (1.0 - cosW) / 2.0 / a0
        lpCoef[1] = (1.0 - cosW) / a0
        lpCoef[2] = (1.0 - cosW) / 2.0 / a0
        lpCoef[3] = (-2.0 * cosW) / a0
        lpCoef[4] = (1.0 - alpha) / a0
    }
}
