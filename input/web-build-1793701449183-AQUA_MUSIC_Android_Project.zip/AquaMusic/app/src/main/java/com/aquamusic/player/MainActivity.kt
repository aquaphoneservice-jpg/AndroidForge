package com.aquamusic.player

import android.Manifest
import android.app.Activity
import android.content.ContentUris
import android.content.pm.PackageManager
import android.database.Cursor
import android.media.AudioManager
import android.media.MediaPlayer
import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.provider.MediaStore
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

data class Track(val id: Long, val title: String, val artist: String, val uri: Uri)

class MainActivity : Activity() {
    private val navy = Color.rgb(8, 20, 48)
    private val panel = Color.rgb(25, 49, 91)
    private val blue = Color.rgb(48, 105, 218)
    private val pale = Color.rgb(218, 226, 241)
    private val tracks = mutableListOf<Track>()
    private var index = -1
    private var player: MediaPlayer? = null
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null
    private lateinit var songTitle: TextView
    private lateinit var songArtist: TextView
    private lateinit var playButton: Button
    private lateinit var playlist: LinearLayout
    private lateinit var status: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = navy
        window.navigationBarColor = navy
        window.decorView.systemUiVisibility = 0
        requestedOrientation = android.content.pm.ActivityInfo.SCREEN_ORIENTATION_PORTRAIT
        buildUi()
        requestAudioPermission()
    }

    private fun bg(color: Int, radius: Float = 18f): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius }

    private fun label(text: String, size: Float, color: Int, bold: Boolean = false): TextView =
        TextView(this).apply {
            this.text = text; textSize = size; setTextColor(color)
            if (bold) setTypeface(null, Typeface.BOLD)
        }

    private fun buildUi() {
        val scroll = ScrollView(this).apply { setBackgroundColor(navy) }
        val page = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 24)
        }
        scroll.addView(page)
        setContentView(scroll)

        val header = label("A Q U A   M U S I C", 21f, pale, true).apply {
            gravity = Gravity.CENTER; setPadding(8, 18, 8, 18)
        }
        page.addView(header)
        val playerCard = card(page, "NOW PLAYING")
        songTitle = label("Pilih lagu dari playlist", 23f, Color.WHITE, true)
        songArtist = label("AQUA MUSIC • OFFLINE PLAYER", 13f, pale)
        playerCard.addView(songTitle)
        playerCard.addView(songArtist)
        val controls = LinearLayout(this).apply {
            gravity = Gravity.CENTER; orientation = LinearLayout.HORIZONTAL
        }
        val prev = actionButton("⏮") { previous() }
        playButton = actionButton("▶") { togglePlayback() }
        val next = actionButton("⏭") { next() }
        controls.addView(prev); controls.addView(playButton); controls.addView(next)
        playerCard.addView(controls)

        val eqCard = card(page, "10 BAND EQUALIZER")
        val presets = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL }
        listOf("FLAT", "BASS", "ROCK", "VOCAL", "POP").forEach { name ->
            val b = Button(this).apply {
                text = name; textSize = 10f; setTextColor(Color.WHITE)
                background = bg(blue, 22f); isAllCaps = false
                setPadding(3, 0, 3, 0)
            }
            presets.addView(b, LinearLayout.LayoutParams(0, 42, 1f).apply { setMargins(2, 4, 2, 4) })
            b.setOnClickListener { applyPreset(name) }
        }
        eqCard.addView(presets)
        val bands = listOf("31", "62", "125", "250", "500", "1K", "2K", "4K", "8K", "16K")
        bands.forEachIndexed { i, freq ->
            val row = LinearLayout(this).apply {
                orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL
            }
            row.addView(label(freq, 12f, pale).apply { width = 48 })
            val seek = SeekBar(this).apply {
                max = 24; progress = 12
                setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                    override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) {
                        if (fromUser) setEqBand(i, (p - 12) * 500)
                    }
                    override fun onStartTrackingTouch(s: SeekBar?) {}
                    override fun onStopTrackingTouch(s: SeekBar?) {}
                })
            }
            row.addView(seek, LinearLayout.LayoutParams(0, 38, 1f))
            eqCard.addView(row)
        }

        val dsp = card(page, "DSP / POWER AMP")
        addSwitch(dsp, "BASS BOOST", true) { enabled ->
            try { bassBoost?.setEnabled(enabled) } catch (_: Exception) {}
        }
        addSwitch(dsp, "STEREO WIDTH", false) { enabled ->
            try { virtualizer?.setEnabled(enabled) } catch (_: Exception) {}
        }
        addSlider(dsp, "PREAMP", 0, 100, 50) { value ->
            try { loudness?.setTargetGain((value - 50) * 100) } catch (_: Exception) {}
        }
        addSwitch(dsp, "NOISE FILTER", false) {
            Toast.makeText(this, "Filter noise lanjutan akan ditambahkan pada versi DSP berikutnya", Toast.LENGTH_SHORT).show()
        }
        addSwitch(dsp, "BASS LIMITER / GUARD", false) {
            Toast.makeText(this, "Proteksi limiter lanjutan akan ditambahkan pada versi DSP berikutnya", Toast.LENGTH_SHORT).show()
        }

        val listCard = card(page, "PLAYLIST OFFLINE")
        status = label("Memindai musik...", 13f, pale)
        listCard.addView(status)
        playlist = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        listCard.addView(playlist)
        val refresh = actionButton("⟳  SCAN ULANG MUSIK") { loadTracks() }
        listCard.addView(refresh)
    }

    private fun card(parent: LinearLayout, title: String): LinearLayout {
        val wrap = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(14, 12, 14, 14)
            background = bg(panel)
        }
        val heading = label(title, 14f, pale, true).apply {
            gravity = Gravity.CENTER; setPadding(0, 2, 0, 14)
        }
        wrap.addView(heading)
        parent.addView(wrap, LinearLayout.LayoutParams(-1, -2).apply { setMargins(0, 8, 0, 8) })
        return wrap
    }

    private fun actionButton(text: String, action: () -> Unit) =
        Button(this).apply {
            this.text = text; textSize = 16f; setTextColor(Color.WHITE)
            background = bg(blue, 28f); isAllCaps = false
            setOnClickListener { action() }
            setPadding(18, 8, 18, 8)
        }

    private fun addSwitch(parent: LinearLayout, title: String, initial: Boolean, changed: (Boolean) -> Unit) {
        val s = Switch(this).apply {
            text = title; textSize = 13f; setTextColor(pale); isChecked = initial
            setOnCheckedChangeListener { _, checked -> changed(checked) }
        }
        parent.addView(s)
    }

    private fun addSlider(parent: LinearLayout, title: String, min: Int, max: Int, initial: Int, changed: (Int) -> Unit) {
        parent.addView(label(title, 13f, pale, true))
        val seek = SeekBar(this).apply {
            this.max = max - min; progress = initial - min
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) { if (fromUser) changed(p + min) }
                override fun onStartTrackingTouch(s: SeekBar?) {}
                override fun onStopTrackingTouch(s: SeekBar?) {}
            })
        }
        parent.addView(seek)
    }

    private fun requestAudioPermission() {
        val permission = if (Build.VERSION.SDK_INT >= 33) Manifest.permission.READ_MEDIA_AUDIO else Manifest.permission.READ_EXTERNAL_STORAGE
        if (checkSelfPermission(permission) == PackageManager.PERMISSION_GRANTED) loadTracks()
        else requestPermissions(arrayOf(permission), 20)
    }

    override fun onRequestPermissionsResult(requestCode: Int, permissions: Array<out String>, grantResults: IntArray) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        if (requestCode == 20 && grantResults.firstOrNull() == PackageManager.PERMISSION_GRANTED) loadTracks()
        else status.text = "Izin akses musik diperlukan untuk membaca lagu."
    }

    private fun loadTracks() {
        tracks.clear(); playlist.removeAllViews()
        val collection = MediaStore.Audio.Media.EXTERNAL_CONTENT_URI
        val projection = arrayOf(MediaStore.Audio.Media._ID, MediaStore.Audio.Media.TITLE, MediaStore.Audio.Media.ARTIST)
        val selection = "${MediaStore.Audio.Media.IS_MUSIC} != 0"
        val sort = "${MediaStore.Audio.Media.TITLE} COLLATE NOCASE ASC"
        try {
            contentResolver.query(collection, projection, selection, null, sort)?.use { c ->
                val idCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media._ID)
                val titleCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.TITLE)
                val artistCol = c.getColumnIndexOrThrow(MediaStore.Audio.Media.ARTIST)
                while (c.moveToNext()) {
                    val id = c.getLong(idCol)
                    val uri = ContentUris.withAppendedId(collection, id)
                    tracks.add(Track(id, c.getString(titleCol) ?: "Unknown", c.getString(artistCol) ?: "Unknown Artist", uri))
                }
            }
        } catch (e: Exception) { status.text = "Gagal membaca musik: ${e.message}" }
        status.text = "${tracks.size} LAGU DITEMUKAN"
        tracks.forEachIndexed { i, track ->
            val item = TextView(this).apply {
                text = "${i + 1}.  ${track.title}\n      ${track.artist}"
                textSize = 14f; setTextColor(Color.WHITE); setPadding(8, 12, 8, 12)
                setOnClickListener { playAt(i) }
            }
            playlist.addView(item)
            val line = View(this).apply { setBackgroundColor(Color.rgb(57, 79, 119)) }
            playlist.addView(line, LinearLayout.LayoutParams(-1, 1))
        }
        if (tracks.isEmpty()) status.text = "Belum ada lagu. Simpan file MP3 di HP lalu scan ulang."
    }

    private fun playAt(i: Int) {
        if (i !in tracks.indices) return
        releaseAudio()
        index = i
        val t = tracks[i]
        player = MediaPlayer().apply {
            setAudioStreamType(AudioManager.STREAM_MUSIC)
            setDataSource(this@MainActivity, t.uri)
            setOnPreparedListener {
                it.start(); playButton.text = "Ⅱ"
                songTitle.text = t.title; songArtist.text = t.artist
                attachEffects(it.audioSessionId)
            }
            setOnCompletionListener { next() }
            prepareAsync()
        }
    }

    private fun attachEffects(session: Int) {
        try {
            equalizer = Equalizer(0, session).apply { enabled = true }
            bassBoost = BassBoost(0, session).apply { setStrength(650); enabled = true }
            virtualizer = Virtualizer(0, session).apply { setStrength(400) }
            loudness = LoudnessEnhancer(session).apply { setTargetGain(0); enabled = true }
        } catch (_: Exception) {}
    }

    private fun setEqBand(index: Int, level: Int) {
        try {
            val eq = equalizer ?: return
            val count = eq.numberOfBands.toInt()
            if (count > 0) {
                val mapped = (index.toFloat() / 9f * (count - 1)).toInt().toShort()
                val range = eq.bandLevelRange
                eq.setBandLevel(mapped, level.coerceIn(range[0].toInt(), range[1].toInt()).toShort())
            }
        } catch (_: Exception) {}
    }

    private fun applyPreset(name: String) {
        val values = when (name) {
            "BASS" -> listOf(6, 5, 4, 2, 0, 0, 0, 0, 0, 0)
            "ROCK" -> listOf(4, 3, -1, -3, 1, 3, 4, 4, 3, 3)
            "VOCAL" -> listOf(-2, -1, 0, 2, 4, 4, 2, 1, 0, -1)
            "POP" -> listOf(-1, 2, 3, 2, 0, -1, 0, 2, 3, 2)
            else -> List(10) { 0 }
        }
        values.forEachIndexed { i, v -> setEqBand(i, v * 100) }
    }

    private fun togglePlayback() {
        val p = player
        if (p == null) { if (tracks.isNotEmpty()) playAt(0); return }
        if (p.isPlaying) { p.pause(); playButton.text = "▶" }
        else { p.start(); playButton.text = "Ⅱ" }
    }
    private fun next() { if (tracks.isNotEmpty()) playAt((index + 1) % tracks.size) }
    private fun previous() { if (tracks.isNotEmpty()) playAt(if (index <= 0) tracks.lastIndex else index - 1) }

    private fun releaseAudio() {
        try { equalizer?.release() } catch (_: Exception) {}
        try { bassBoost?.release() } catch (_: Exception) {}
        try { virtualizer?.release() } catch (_: Exception) {}
        try { loudness?.release() } catch (_: Exception) {}
        equalizer = null; bassBoost = null; virtualizer = null; loudness = null
        try { player?.release() } catch (_: Exception) {}
        player = null
    }

    override fun onDestroy() { releaseAudio(); super.onDestroy() }
}
