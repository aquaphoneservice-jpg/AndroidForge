# AQUA MUSIC

Starter project Android Native (Kotlin) untuk pemutar musik offline.

## Fitur pada versi awal
- Memindai file audio lokal melalui MediaStore.
- Daftar lagu, play/pause, next, previous.
- Kontrol Equalizer Android, BassBoost, Virtualizer, dan LoudnessEnhancer jika didukung perangkat.
- UI gelap navy/biru dengan panel audio.

## Build APK
1. Buka folder project ini di Android Studio atau unggah ZIP ke AndroidForge.
2. Gunakan JDK 17.
3. Jalankan `gradle assembleDebug`.
4. APK debug: `app/build/outputs/apk/debug/app-debug.apk`.

## Catatan DSP penting
API Equalizer Android bergantung pada implementasi vendor/perangkat. UI menyediakan 10 slider, tetapi efek sistem yang tersedia bisa memiliki jumlah band berbeda; slider dipetakan ke band perangkat terdekat. BassBoost, Virtualizer, dan LoudnessEnhancer juga dapat tidak didukung pada beberapa perangkat. Noise reduction dan limiter digital khusus belum diimplementasikan pada starter ini dan memerlukan pipeline pemrosesan PCM/NDK untuk hasil yang konsisten. Aplikasi ini adalah fondasi awal, bukan klaim DSP profesional atau pemrosesan audio system-wide.

## Identitas
Nama aplikasi: AQUA MUSIC
Package: `com.aquamusic.player`
Minimum Android: 6.0 (API 23)
