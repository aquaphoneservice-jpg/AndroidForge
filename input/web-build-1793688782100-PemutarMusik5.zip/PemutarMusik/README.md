# Pemutar Musik (Android) - skin Ocean Blue

Jendela: PEMUTAR MUSIK (tombol minimize = mini player melayang), EQUALIZER 10 BAND, DSP / POWER AMP, PLAYLIST.

## Fitur
- Acak (shuffle) dan Ulang (mati / semua / 1 lagu), masing-masing dengan LED.
- 3 warna lampu LED: OCEAN, AURORA, SUNSET (tombol warna di baris bawah, atau ketuk spectrum).
- Playlist: tekan lama lagu -> Pindah ke album, Hapus lagu, Rincian (+ Naikkan/Turunkan urutan, Keluarkan dari album saat di dalam album).
- Album = playlist buatan sendiri: tombol "+" buat album, tekan lama nama album -> Ganti nama / Hapus album,
  tombol TAMBAH untuk memilih banyak lagu sesuai urutan ketukan.
- Suara: auto headroom, limiter look-ahead, bass guard otomatis, power amp 0..+12 dB.

## Cara pakai
1. Android Studio terbaru, File > Open > pilih folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging), Run. Beri izin akses musik.
Min Android 7.0 (API 24).
