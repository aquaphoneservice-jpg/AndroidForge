KonterKu - proyek Android (WebView)
Upload ZIP ini ke AndroidForge (Android APK, variant: auto atau debug).
Aplikasi ada di app/src/main/assets/index.html
Nama aplikasi: KonterKu. ID aplikasi: com.konterku.app (berbeda dari Kasir Ponsel, jadi bisa terpasang berdampingan).
Data tidak ikut dari aplikasi lama: pindahkan lewat Laporan > Backup di aplikasi lama, lalu Laporan > Impor di KonterKu.
