# Pemutar Musik (Android) - tampilan klasik

Pemutar MP3 dengan 4 "jendela" bergaya pemutar desktop era 90-an:
- PEMUTAR MUSIK: waktu LCD, spectrum analyzer 19 bar, judul berjalan, volume, seek, transport, SHUF/REP
- EQUALIZER 10 BAND: preamp + 10 band (31 Hz - 16 kHz, +-12 dB), preset
- DSP / POWER AMP: noise filter, bass booster, stereo width, power amp, meter bass guard
- PLAYLIST: semua MP3 di HP

Bass Guard (anti-geber) selalu aktif otomatis, tanpa tombol.

## Cara pakai
1. Install Android Studio terbaru, File > Open > pilih folder ini.
2. Tunggu Gradle sync (butuh internet pertama kali).
3. Colok HP (USB debugging aktif), klik Run. Atau Build > Build APK(s).
4. Beri izin akses musik saat diminta.

Min Android 7.0 (API 24).
