package com.example.pemutarmusik.audio

import android.content.Context
import android.content.SharedPreferences
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EqSettings(
    val enabled: Boolean = true,
    val gains: List<Float> = List(EqAudioProcessor.BAND_COUNT) { 0f },
    val preampDb: Float = 0f,
    val noiseFilter: Boolean = true,
    val bassBoost: Float = 0f,   // 0..1
    val width: Float = 1f,       // 0..2
    val ampDb: Float = 0f,       // 0..9
)

object Presets {
    val all: List<Pair<String, List<Float>>> = listOf(
        "FLAT" to List(10) { 0f },
        "BASS" to listOf(5f, 4f, 3f, 1f, 0f, 0f, 0f, 0f, 0f, 0f),
        "ROCK" to listOf(4f, 3f, 2f, 0f, -1f, -1f, 1f, 3f, 4f, 4f),
        "VOKAL" to listOf(-2f, -2f, -1f, 1f, 3f, 3f, 3f, 2f, 0f, -1f),
        "POP" to listOf(-1f, 1f, 3f, 4f, 3f, 0f, -1f, -1f, 1f, 2f),
    )
}

/**
 * Pemegang tunggal pengaturan audio: dipakai bersama oleh PlaybackService (memutar)
 * dan UI (mengubah). Pengaturan disimpan otomatis.
 * Bass Guard tidak punya pengaturan: selalu aktif dan otomatis.
 */
object AudioEngine {
    val processor = EqAudioProcessor()

    private val _settings = MutableStateFlow(EqSettings())
    val settings: StateFlow<EqSettings> = _settings.asStateFlow()

    private var prefs: SharedPreferences? = null

    @Synchronized
    fun init(context: Context) {
        if (prefs != null) return
        val p = context.applicationContext.getSharedPreferences("dsp", Context.MODE_PRIVATE)
        prefs = p

        val saved = p.getString("gains", null)
            ?.split(",")
            ?.mapNotNull { it.toFloatOrNull() }
            ?.takeIf { it.size == EqAudioProcessor.BAND_COUNT }
        val loaded = EqSettings(
            enabled = p.getBoolean("enabled", true),
            gains = saved ?: List(EqAudioProcessor.BAND_COUNT) { 0f },
            preampDb = p.getFloat("preamp", 0f),
            noiseFilter = p.getBoolean("noise", true),
            bassBoost = p.getFloat("boost", 0f),
            width = p.getFloat("width", 1f),
            ampDb = p.getFloat("amp", 0f),
        )
        _settings.value = loaded
        apply(loaded)
    }

    fun update(block: (EqSettings) -> EqSettings) {
        val next = block(_settings.value)
        _settings.value = next
        apply(next)
        save(next)
    }

    private fun apply(s: EqSettings) {
        processor.setParams(
            DspParams(
                eqEnabled = s.enabled,
                gains = s.gains.toFloatArray(),
                preampDb = s.preampDb,
                noiseFilter = s.noiseFilter,
                bassBoost = s.bassBoost,
                width = s.width,
                ampDb = s.ampDb,
            )
        )
    }

    private fun save(s: EqSettings) {
        prefs?.edit()
            ?.putBoolean("enabled", s.enabled)
            ?.putString("gains", s.gains.joinToString(","))
            ?.putFloat("preamp", s.preampDb)
            ?.putBoolean("noise", s.noiseFilter)
            ?.putFloat("boost", s.bassBoost)
            ?.putFloat("width", s.width)
            ?.putFloat("amp", s.ampDb)
            ?.apply()
    }
}
