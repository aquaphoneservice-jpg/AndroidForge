package com.example.pemutarmusik

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.awaitEachGesture
import androidx.compose.foundation.gestures.awaitFirstDown
import androidx.compose.foundation.gestures.drag
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.ColumnScope
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.lerp
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.pemutarmusik.audio.AudioEngine
import com.example.pemutarmusik.audio.SpectrumAnalyzer
import kotlin.math.max

// ------------------------------------------------------------------ warna "skin" klasik

val WA_DESK = Color(0xFF101018)
val WA_PANEL = Color(0xFF2E3044)
val WA_HI = Color(0xFF7F82A3)
val WA_LO = Color(0xFF0B0B14)
val WA_GREEN = Color(0xFF00E800)
val WA_GREEN_DIM = Color(0xFF0E5A0E)
val WA_TEXT = Color(0xFFC8CCE8)
val WA_SEL = Color(0xFF0000C6)
val MONO = FontFamily.Monospace

/** Efek tombol/panel timbul (raised) atau tenggelam (inset) khas era 90-an. */
fun Modifier.bevel(raised: Boolean = true, fill: Color = WA_PANEL): Modifier = this.drawBehind {
    drawRect(fill)
    val t = 1.dp.toPx()
    val hi = if (raised) WA_HI else WA_LO
    val lo = if (raised) WA_LO else WA_HI
    drawRect(hi, Offset.Zero, Size(size.width, t))
    drawRect(hi, Offset.Zero, Size(t, size.height))
    drawRect(lo, Offset(0f, size.height - t), Size(size.width, t))
    drawRect(lo, Offset(size.width - t, 0f), Size(t, size.height))
}

// ------------------------------------------------------------------ jendela

@Composable
fun WaWindow(
    title: String,
    modifier: Modifier = Modifier,
    fill: Boolean = false,
    content: @Composable ColumnScope.() -> Unit,
) {
    Column(modifier.fillMaxWidth().bevel(true, WA_PANEL)) {
        Row(
            Modifier
                .fillMaxWidth()
                .height(15.dp)
                .background(Brush.horizontalGradient(listOf(Color(0xFF4A5A8E), Color(0xFF1C2244))))
                .padding(horizontal = 3.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Stripes(Modifier.weight(1f))
            Text(
                title,
                color = Color.White,
                fontSize = 9.sp,
                fontFamily = MONO,
                fontWeight = FontWeight.Bold,
                letterSpacing = 1.sp,
                modifier = Modifier.padding(horizontal = 6.dp),
            )
            Stripes(Modifier.weight(1f))
        }
        val inner = if (fill) Modifier.weight(1f) else Modifier
        Column(inner.padding(4.dp), content = content)
    }
}

@Composable
private fun Stripes(modifier: Modifier) {
    Canvas(modifier.height(9.dp)) {
        for (y in listOf(1.dp, 4.dp, 7.dp)) {
            val py = y.toPx()
            drawLine(Color(0x66FFFFFF), Offset(0f, py), Offset(size.width, py), strokeWidth = 1.dp.toPx())
        }
    }
}

// ------------------------------------------------------------------ tombol

@Composable
fun WaButton(
    label: String,
    onClick: () -> Unit,
    modifier: Modifier = Modifier,
    active: Boolean = false,
) {
    Box(
        modifier
            .height(20.dp)
            .bevel(!active, if (active) Color(0xFF1B1E30) else WA_PANEL)
            .clickable(onClick = onClick)
            .padding(horizontal = 6.dp),
        contentAlignment = Alignment.Center,
    ) {
        Text(
            label,
            fontSize = 9.sp,
            fontFamily = MONO,
            fontWeight = FontWeight.Bold,
            color = if (active) WA_GREEN else WA_TEXT,
        )
    }
}

@Composable
fun WaIconButton(icon: ImageVector, description: String, onClick: () -> Unit, modifier: Modifier = Modifier) {
    Box(
        modifier
            .size(width = 34.dp, height = 24.dp)
            .bevel(true, WA_PANEL)
            .clickable(onClick = onClick),
        contentAlignment = Alignment.Center,
    ) {
        Icon(icon, contentDescription = description, tint = WA_TEXT, modifier = Modifier.size(17.dp))
    }
}

// ------------------------------------------------------------------ slider

/**
 * Slider gaya Winamp, horizontal atau vertikal.
 * centered = true: isi warna dari titik tengah (dipakai untuk EQ +/- dB).
 */
@Composable
fun WaSlider(
    value: Float,
    onValueChange: (Float) -> Unit,
    range: ClosedFloatingPointRange<Float>,
    modifier: Modifier = Modifier,
    vertical: Boolean = false,
    centered: Boolean = false,
    enabled: Boolean = true,
    onDone: () -> Unit = {},
) {
    val change by rememberUpdatedState(onValueChange)
    val done by rememberUpdatedState(onDone)
    val thumb = 12.dp

    Canvas(
        modifier.pointerInput(enabled, vertical, range) {
            if (!enabled) return@pointerInput
            val pad = thumb.toPx() / 2f
            fun update(p: Offset) {
                val len = (if (vertical) size.height else size.width).toFloat()
                val pos = if (vertical) p.y else p.x
                var frac = ((pos - pad) / max(len - 2 * pad, 1f)).coerceIn(0f, 1f)
                if (vertical) frac = 1f - frac
                change(range.start + frac * (range.endInclusive - range.start))
            }
            awaitEachGesture {
                val down = awaitFirstDown()
                update(down.position)
                down.consume()
                drag(down.id) {
                    update(it.position)
                    it.consume()
                }
                done()
            }
        }
    ) {
        val pad = thumb.toPx() / 2f
        val grooveW = 4.dp.toPx()
        val frac = ((value - range.start) / (range.endInclusive - range.start)).coerceIn(0f, 1f)
        val len = if (vertical) size.height else size.width
        val cross = if (vertical) size.width else size.height
        val track = len - 2 * pad
        val pos = pad + (if (vertical) (1f - frac) else frac) * track
        val centerPos = pad + track / 2f

        // alur (groove) tenggelam
        val gTop = (cross - grooveW) / 2f
        if (vertical) {
            drawRect(Color.Black, Offset(gTop, pad), Size(grooveW, track))
        } else {
            drawRect(Color.Black, Offset(pad, gTop), Size(track, grooveW))
        }

        // isi warna
        val a = if (centered) centerPos else (if (vertical) pad + track else pad)
        val lo = minOf(a, pos)
        val hi = maxOf(a, pos)
        val dev = if (centered) kotlin.math.abs(frac - 0.5f) * 2f else frac * 0.6f
        val fillColor = if (!enabled) Color(0xFF3A3A44) else lerp(WA_GREEN, Color(0xFFE8B000), dev.coerceIn(0f, 1f)).let {
            if (dev > 0.75f) lerp(it, Color(0xFFE82800), (dev - 0.75f) * 4f) else it
        }
        if (vertical) {
            drawRect(fillColor, Offset(gTop, lo), Size(grooveW, hi - lo))
        } else {
            drawRect(fillColor, Offset(lo, gTop), Size(hi - lo, grooveW))
        }

        // garis tengah
        if (centered) {
            val tick = Color(0x88FFFFFF)
            if (vertical) drawLine(tick, Offset(0f, centerPos), Offset(size.width, centerPos), 1.dp.toPx())
            else drawLine(tick, Offset(centerPos, 0f), Offset(centerPos, size.height), 1.dp.toPx())
        }

        // gagang
        val body = if (enabled) Color(0xFFB4B7D0) else Color(0xFF6A6C7C)
        val tw = thumb.toPx()
        val topLeft = if (vertical) Offset(1.dp.toPx(), pos - tw / 2f) else Offset(pos - tw / 2f, 1.dp.toPx())
        val sz = if (vertical) Size(size.width - 2.dp.toPx(), tw) else Size(tw, size.height - 2.dp.toPx())
        drawRect(body, topLeft, sz)
        drawRect(Color.White.copy(alpha = 0.6f), topLeft, sz, style = Stroke(1.dp.toPx()))
        drawRect(Color(0xFF30334A), topLeft + Offset(sz.width * 0.5f - 0.5.dp.toPx(), 0f), Size(1.dp.toPx(), sz.height))
    }
}

// ------------------------------------------------------------------ spectrum analyzer

@Composable
fun SpectrumView(playing: Boolean, modifier: Modifier = Modifier) {
    val analyzer = remember { SpectrumAnalyzer(AudioEngine.processor) }
    val bars0 = SpectrumAnalyzer.BARS
    var bars by remember { mutableStateOf(FloatArray(bars0)) }
    val peaks = remember { FloatArray(bars0) }
    val playingNow by rememberUpdatedState(playing)

    LaunchedEffect(Unit) {
        var last = 0L
        while (true) {
            val now = androidx.compose.runtime.withFrameNanos { it }
            if (now - last < 30_000_000L) continue
            last = now
            val old = bars
            val idle = !playingNow && old.all { it <= 0f } && peaks.all { it <= 0f }
            if (idle) continue
            val fresh = if (playingNow) analyzer.compute() else FloatArray(bars0)
            val next = FloatArray(bars0) { i -> max(fresh[i], old[i] - 0.07f) }
            for (i in 0 until bars0) peaks[i] = max(next[i], max(peaks[i] - 0.015f, 0f))
            bars = next
        }
    }

    Canvas(modifier) {
        val b = bars
        val n = b.size
        val gap = 1.dp.toPx()
        val w = (size.width - gap * (n - 1)) / n
        val segs = 14
        val segH = size.height / segs
        for (i in 0 until n) {
            val x = i * (w + gap)
            val lit = (b[i] * segs).toInt()
            for (s in 0 until lit) {
                val t = s / (segs - 1f)
                val color = when {
                    t < 0.55f -> lerp(Color(0xFF10B810), Color(0xFFB8E800), t / 0.55f)
                    else -> lerp(Color(0xFFB8E800), Color(0xFFE82010), (t - 0.55f) / 0.45f)
                }
                val y = size.height - (s + 1) * segH
                drawRect(color, Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
            val pk = (peaks[i] * segs).toInt().coerceIn(0, segs - 1)
            if (peaks[i] > 0.02f) {
                val y = size.height - (pk + 1) * segH
                drawRect(Color(0xFFE0E0E0), Offset(x, y + 0.5f), Size(w, segH - 1f))
            }
        }
    }
}
