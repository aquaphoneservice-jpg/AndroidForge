package com.example.pemutarmusik

import android.content.ContentUris
import android.content.Context
import android.net.Uri
import android.os.Build
import android.provider.MediaStore
import android.provider.MediaStore.Audio.Media
import androidx.media3.common.MediaItem
import androidx.media3.common.MediaMetadata

data class Song(
    val id: Long,
    val title: String,
    val artist: String,
    val durationMs: Long,
    val uri: Uri,
) {
    fun toMediaItem(): MediaItem = MediaItem.Builder()
        .setMediaId(id.toString())
        .setUri(uri)
        .setMediaMetadata(
            MediaMetadata.Builder()
                .setTitle(title)
                .setArtist(artist)
                .build()
        )
        .build()
}

object MusicRepository {

    /** Ambil semua file MP3 di penyimpanan lewat MediaStore. Panggil dari thread background. */
    fun loadMp3(context: Context): List<Song> {
        val collection: Uri = if (Build.VERSION.SDK_INT >= 29) {
            Media.getContentUri(MediaStore.VOLUME_EXTERNAL)
        } else {
            Media.EXTERNAL_CONTENT_URI
        }
        val projection = arrayOf(Media._ID, Media.TITLE, Media.ARTIST, Media.DURATION)

        // Durasi >= 10 detik: menyaring nada dering / suara notifikasi pendek.
        val selection = "(${Media.MIME_TYPE} = ? OR ${Media.DISPLAY_NAME} LIKE ?) AND ${Media.DURATION} >= 10000"
        val args = arrayOf("audio/mpeg", "%.mp3")

        val songs = mutableListOf<Song>()
        context.contentResolver.query(
            collection, projection, selection, args, "${Media.TITLE} COLLATE NOCASE ASC"
        )?.use { c ->
            val idCol = c.getColumnIndexOrThrow(Media._ID)
            val titleCol = c.getColumnIndexOrThrow(Media.TITLE)
            val artistCol = c.getColumnIndexOrThrow(Media.ARTIST)
            val durCol = c.getColumnIndexOrThrow(Media.DURATION)
            while (c.moveToNext()) {
                val id = c.getLong(idCol)
                val artist = c.getString(artistCol)
                songs += Song(
                    id = id,
                    title = c.getString(titleCol) ?: "Tanpa judul",
                    artist = if (artist.isNullOrBlank() || artist == "<unknown>") "Tidak diketahui" else artist,
                    durationMs = c.getLong(durCol),
                    uri = ContentUris.withAppendedId(Media.EXTERNAL_CONTENT_URI, id),
                )
            }
        }
        return songs
    }
}
