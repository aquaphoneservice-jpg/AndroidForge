# MP3 (Android) - skin Ocean Blue

Jendela: PEMUTAR MUSIK (tombol minimize = mini player melayang), EQUALIZER 10 BAND, DSP / POWER AMP, PLAYLIST.

## Fitur
- Acak (shuffle) dan Ulang (mati / semua / 1 lagu), masing-masing dengan LED.
- Skin permanen OCEAN (tombol ganti skin dihapus).
- Playlist: tekan lama lagu -> Pindah ke album, Hapus lagu, Rincian (+ Naikkan/Turunkan urutan, Keluarkan dari album saat di dalam album).
- Album = playlist buatan sendiri: tombol "+" buat album, tekan lama nama album -> Ganti nama / Hapus album,
  tombol TAMBAH untuk memilih banyak lagu sesuai urutan ketukan.
- Suara: auto headroom, limiter look-ahead, bass guard otomatis, power amp 0..+12 dB.

## Cara pakai
1. Android Studio terbaru, File > Open > pilih folder ini, tunggu Gradle sync.
2. Colok HP (USB debugging), Run. Beri izin akses musik.
Min Android 7.0 (API 24).

## Catatan v6
- Nama aplikasi: MP3, ikon baru gradasi violet-magenta-coral (adaptive icon).
- Tombol utama: sebelumnya / jeda / putar (tengah, lebih besar) / henti / berikutnya (5 tombol, juga di mini player; tombol sesuai status tetap menyala, mini player selalu di tengah dan hanya digeser naik/turun, menyala biru tua OCEAN saat ditekan). Tombol acak dan ulang ada di baris bawah bersama EQ/DSP/PL; 5 tombol transport di tengah. Font playlist diperbesar.
- Playlist punya kolom cari di bagian bawah.
- Mini player melayang punya grafik spectrum warna.

## Instal tanpa peringatan Play Protect (sebisanya)
Peringatan Play Protect muncul untuk aplikasi di luar Play Store dari developer yang belum dikenal; tidak bisa dihilangkan 100% lewat kode.
1. Buat kunci tanda tangan sendiri (sekali saja, simpan baik-baik, jangan hilang):
   `keytool -genkeypair -v -keystore pemutarmusik.jks -alias pemutarmusik -keyalg RSA -keysize 2048 -validity 10000`
2. Salin `keystore.properties.example` jadi `keystore.properties`, isi password, taruh `.jks` di folder yang sama.
3. Build rilis: `./gradlew assembleRelease` (APK bertanda tangan tetap, bukan debug). Pakai kunci yang sama untuk semua versi.
4. Tanpa peringatan sama sekali: unggah ke Google Play Console (pengujian internal/tertutup), lalu instal dari tautan Play Store.
5. Hanya di HP sendiri: pilih "Instal saja" sekali, atau matikan "Pindai aplikasi dengan Play Protect", atau instal lewat `adb install`.

## Tampilan landscape
- Aplikasi dikunci landscape (`sensorLandscape`, boleh terbalik 180 derajat).
- Layar dibagi 2: kiri = player + EQ/DSP bertumpuk (bisa digulir), kanan = playlist.
- Tombol PL menyembunyikan playlist (panel kiri melebar); tombol EQ dan DSP menampilkan/menyembunyikan panelnya.
